import type { ChatMessage } from './supabase';

export async function callGemini(messages: ChatMessage[], history: ChatMessage[]): Promise<string> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/gemini-proxy`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
  if (anonKey) {
    headers['Authorization'] = `Bearer ${anonKey}`;
  }

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers,
    body: JSON.stringify({ messages, history }),
  });

  if (!response.ok) {
    const errBody = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(errBody.error || `Request failed (${response.status})`);
  }

  const data = await response.json();
  if (typeof data.response !== 'string') {
    throw new Error('Unexpected response format from assistant');
  }

  return data.response as string;
}
