import {
  Mail, Calendar, HardDrive, FileText, Sheet, Presentation,
  Images, MessageSquare, Video, Phone, Cloud, BookOpen,
  Globe, StickyNote, ListChecks
} from 'lucide-react';

export type AppId =
  | 'home'
  | 'email'
  | 'calendar'
  | 'drive'
  | 'docs'
  | 'sheets'
  | 'slides'
  | 'photos'
  | 'chat'
  | 'meet'
  | 'phone'
  | 'keep'
  | 'tasks'
  | 'contacts'
  | 'translate'
  | 'books';

export interface AppDef {
  id: AppId;
  name: string;
  icon: typeof Mail;
  gradient: string;
  iconColor: string;
  description: string;
}

export const apps: AppDef[] = [
  { id: 'email', name: 'SIT Email', icon: Mail, gradient: 'from-red-50 to-red-100 dark:from-red-950/40 dark:to-red-900/20', iconColor: 'text-red-500', description: 'Email' },
  { id: 'calendar', name: 'Calendar', icon: Calendar, gradient: 'from-blue-50 to-blue-100 dark:from-blue-950/40 dark:to-blue-900/20', iconColor: 'text-blue-500', description: 'Schedule' },
  { id: 'drive', name: 'Drive', icon: HardDrive, gradient: 'from-emerald-50 to-emerald-100 dark:from-emerald-950/40 dark:to-emerald-900/20', iconColor: 'text-emerald-500', description: 'Storage' },
  { id: 'docs', name: 'Docs', icon: FileText, gradient: 'from-blue-50 to-indigo-100 dark:from-blue-950/40 dark:to-indigo-900/20', iconColor: 'text-blue-600', description: 'Documents' },
  { id: 'sheets', name: 'Sheets', icon: Sheet, gradient: 'from-green-50 to-emerald-100 dark:from-green-950/40 dark:to-emerald-900/20', iconColor: 'text-green-600', description: 'Spreadsheets' },
  { id: 'slides', name: 'Slides', icon: Presentation, gradient: 'from-amber-50 to-orange-100 dark:from-amber-950/40 dark:to-orange-900/20', iconColor: 'text-amber-500', description: 'Presentations' },
  { id: 'photos', name: 'Photos', icon: Images, gradient: 'from-purple-50 to-pink-100 dark:from-purple-950/40 dark:to-pink-900/20', iconColor: 'text-purple-500', description: 'Gallery' },
  { id: 'chat', name: 'Chat', icon: MessageSquare, gradient: 'from-teal-50 to-cyan-100 dark:from-teal-950/40 dark:to-cyan-900/20', iconColor: 'text-teal-500', description: 'Messaging' },
  { id: 'meet', name: 'Meet', icon: Video, gradient: 'from-green-50 to-teal-100 dark:from-green-950/40 dark:to-teal-900/20', iconColor: 'text-green-600', description: 'Video calls' },
  { id: 'phone', name: 'Phone', icon: Phone, gradient: 'from-blue-50 to-cyan-100 dark:from-blue-950/40 dark:to-cyan-900/20', iconColor: 'text-blue-400', description: 'Calls' },
  { id: 'keep', name: 'Keep', icon: StickyNote, gradient: 'from-amber-50 to-yellow-100 dark:from-amber-950/40 dark:to-yellow-900/20', iconColor: 'text-amber-600', description: 'Notes' },
  { id: 'tasks', name: 'Tasks', icon: ListChecks, gradient: 'from-emerald-50 to-green-100 dark:from-emerald-950/40 dark:to-green-900/20', iconColor: 'text-emerald-600', description: 'To-do list' },
  { id: 'contacts', name: 'Contacts', icon: BookOpen, gradient: 'from-blue-50 to-sky-100 dark:from-blue-950/40 dark:to-sky-900/20', iconColor: 'text-blue-500', description: 'People' },
  { id: 'translate', name: 'Translate', icon: Globe, gradient: 'from-blue-50 to-indigo-100 dark:from-blue-950/40 dark:to-indigo-900/20', iconColor: 'text-blue-400', description: 'Translate' },
  { id: 'books', name: 'Books', icon: BookOpen, gradient: 'from-orange-50 to-red-100 dark:from-orange-950/40 dark:to-red-900/20', iconColor: 'text-orange-500', description: 'Reading' },
];

export const appById = (id: AppId): AppDef | undefined =>
  id === 'home' ? undefined : apps.find((a) => a.id === id);
