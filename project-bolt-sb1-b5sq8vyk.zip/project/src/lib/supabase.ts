import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  event_date: string;
  event_time: string;
  color: string;
  created_at: string;
}

export interface DriveFile {
  id: string;
  name: string;
  category: 'documents' | 'photos' | 'archives';
  size_bytes: number;
  created_at: string;
}

export interface Email {
  id: string;
  sender: string;
  recipient: string;
  subject: string;
  body: string;
  folder: 'inbox' | 'sent' | 'drafts' | 'trash';
  is_starred: boolean;
  is_read: boolean;
  created_at: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  color: string;
  created_at: string;
}

export interface Task {
  id: string;
  title: string;
  completed: boolean;
  created_at: string;
}

export interface Contact {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  created_at: string;
}

export interface Document {
  id: string;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
}

export interface Spreadsheet {
  id: string;
  title: string;
  data: string[][];
  created_at: string;
  updated_at: string;
}

export interface Presentation {
  id: string;
  title: string;
  slides: { title: string; content: string }[];
  created_at: string;
  updated_at: string;
}

export interface Photo {
  id: string;
  title: string;
  image_url: string;
  created_at: string;
}

export interface Form {
  id: string;
  title: string;
  description: string;
  questions: { question: string; type: string }[];
  created_at: string;
}
