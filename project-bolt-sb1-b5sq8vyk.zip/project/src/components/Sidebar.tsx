import { LayoutGrid, Home } from 'lucide-react';
import { apps, type AppId } from '@/lib/apps';

interface SidebarProps {
  open: boolean;
  onClose: () => void;
  activeApp: AppId;
  onNavigate: (id: AppId) => void;
}

export default function Sidebar({ open, onClose, activeApp, onNavigate }: SidebarProps) {
  return (
    <>
      {open && (
        <div className="fixed inset-0 bg-black/40 z-40 lg:hidden backdrop-blur-sm" onClick={onClose} />
      )}
      <aside className={`fixed top-0 left-0 h-full w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 z-50 transform transition-transform duration-300 lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'} overflow-y-auto`}>
        <div className="flex items-center gap-2 px-6 h-16 border-b border-gray-200 dark:border-gray-800 sticky top-0 bg-white dark:bg-gray-900 z-10">
          <div className="flex items-center gap-1.5">
            <span className="text-2xl font-medium text-blue-500">S</span>
            <span className="text-2xl font-medium text-red-500">I</span>
            <span className="text-2xl font-medium text-amber-500">T</span>
          </div>
          <span className="ml-1 text-xs font-medium text-gray-400 dark:text-gray-500 tracking-wide">Dashboard</span>
        </div>

        <nav className="p-3">
          <button
            onClick={() => onNavigate('home')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-full text-sm font-medium mb-2 transition-colors ${
              activeApp === 'home'
                ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400'
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <Home className="w-5 h-5" />
            Home
          </button>

          <div className="px-3 py-2 text-xs font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider">
            Apps
          </div>

          <div className="space-y-0.5">
            {apps.map((app) => (
              <button
                key={app.id}
                onClick={() => onNavigate(app.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-full text-sm font-medium transition-colors ${
                  activeApp === app.id
                    ? 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                <app.icon className={`w-5 h-5 ${app.iconColor}`} />
                {app.name}
              </button>
            ))}
          </div>
        </nav>
      </aside>
    </>
  );
}
