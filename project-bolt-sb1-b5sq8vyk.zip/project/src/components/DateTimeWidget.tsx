import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

export default function DateTimeWidget() {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const hours = now.getHours();
  const minutes = now.getMinutes().toString().padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 || 12;

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  return (
    <div className="bg-gradient-to-br from-gray-900 to-gray-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-5 text-white shadow-md">
      <div className="flex items-center gap-2 mb-3">
        <Clock className="w-4 h-4 text-gray-400" />
        <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">Local Time</span>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-4xl font-light tracking-tight">{displayHours}:{minutes}</span>
        <span className="text-sm font-medium text-gray-400">{ampm}</span>
      </div>
      <div className="mt-2 text-sm text-gray-300">
        {days[now.getDay()]}, {months[now.getMonth()]} {now.getDate()}
      </div>
    </div>
  );
}
