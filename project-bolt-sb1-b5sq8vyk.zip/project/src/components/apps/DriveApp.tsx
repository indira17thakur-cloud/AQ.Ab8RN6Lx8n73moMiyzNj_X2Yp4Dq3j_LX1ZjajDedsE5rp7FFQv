import { useState, useEffect, useCallback } from 'react';
import { supabase, type DriveFile } from '@/lib/supabase';
import { Plus, Trash2, X, FileText, Image, Archive, HardDrive, Upload } from 'lucide-react';

const CATEGORIES = [
  { key: 'documents' as const, label: 'Documents', icon: FileText, color: 'text-blue-500', bg: 'bg-blue-50 dark:bg-blue-950/30' },
  { key: 'photos' as const, label: 'Photos', icon: Image, color: 'text-purple-500', bg: 'bg-purple-50 dark:bg-purple-950/30' },
  { key: 'archives' as const, label: 'Archives', icon: Archive, color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-950/30' },
];

const TOTAL_GB = 30;
const TOTAL_BYTES = TOTAL_GB * 1024 * 1024 * 1024;

function formatSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

export default function DriveApp() {
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [filter, setFilter] = useState<'all' | 'documents' | 'photos' | 'archives'>('all');
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState<'documents' | 'photos' | 'archives'>('documents');
  const [newSize, setNewSize] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchFiles = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('drive_files').select('*').order('created_at', { ascending: false });
    if (error) console.error('Failed to load files:', error.message);
    else setFiles(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchFiles(); }, [fetchFiles]);

  const addFile = async () => {
    if (!newName.trim()) return;
    const sizeBytes = Math.max(0, Math.floor(parseFloat(newSize) || 0));
    const { data, error } = await supabase
      .from('drive_files').insert({ name: newName, category: newCategory, size_bytes: sizeBytes }).select('*').single();
    if (error) { console.error('Failed:', error.message); return; }
    setFiles([data as DriveFile, ...files]);
    setNewName(''); setNewSize(''); setShowAdd(false);
  };

  const deleteFile = async (id: string) => {
    await supabase.from('drive_files').delete().eq('id', id);
    setFiles(files.filter((f) => f.id !== id));
  };

  const totalUsed = files.reduce((sum, f) => sum + f.size_bytes, 0);
  const percentage = Math.min(100, (totalUsed / TOTAL_BYTES) * 100);
  const filtered = filter === 'all' ? files : files.filter((f) => f.category === filter);
  const catIcon = (cat: string) => CATEGORIES.find((c) => c.key === cat) || CATEGORIES[0];

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">My Drive</h2>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600">
          <Upload className="w-4 h-4" /> Upload
        </button>
      </div>

      {showAdd && (
        <div className="p-4 border-b border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-gray-500">Add File</span>
            <button onClick={() => setShowAdd(false)}><X className="w-4 h-4 text-gray-400" /></button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
            <input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="File name" className="px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400" />
            <select value={newCategory} onChange={(e) => setNewCategory(e.target.value as 'documents' | 'photos' | 'archives')} className="px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm">
              <option value="documents">Documents</option><option value="photos">Photos</option><option value="archives">Archives</option>
            </select>
            <input type="number" value={newSize} onChange={(e) => setNewSize(e.target.value)} placeholder="Size (bytes)" min="0" className="px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400" />
            <button onClick={addFile} disabled={!newName.trim()} className="py-2 rounded-lg bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600 disabled:opacity-40">Add</button>
          </div>
        </div>
      )}

      <div className="flex gap-2 p-4 border-b border-gray-200 dark:border-gray-800">
        {['all', 'documents', 'photos', 'archives'].map((f) => (
          <button key={f} onClick={() => setFilter(f as 'all' | 'documents' | 'photos' | 'archives')} className={`px-3 py-1.5 rounded-full text-xs font-medium capitalize ${filter === f ? 'bg-emerald-500 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-500'}`}>
            {f}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-auto p-4">
        {loading ? (
          <div className="text-center text-sm text-gray-400 py-8">Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <HardDrive className="w-12 h-12 text-gray-300 dark:text-gray-700 mb-3" />
            <p className="text-sm text-gray-400">No files in your Drive</p>
            <p className="text-xs text-gray-300 dark:text-gray-600 mt-1">Click Upload to add files</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {filtered.map((file) => {
              const cat = catIcon(file.category);
              return (
                <div key={file.id} className="group p-4 rounded-xl border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all">
                  <div className={`w-12 h-12 rounded-xl ${cat.bg} flex items-center justify-center mb-3`}>
                    <cat.icon className={`w-6 h-6 ${cat.color}`} />
                  </div>
                  <div className="text-sm font-medium text-gray-700 dark:text-gray-200 truncate">{file.name}</div>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-xs text-gray-400">{formatSize(file.size_bytes)}</span>
                    <button onClick={() => deleteFile(file.id)} className="opacity-0 group-hover:opacity-100 p-1"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="p-4 border-t border-gray-200 dark:border-gray-800">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-gray-400">{formatSize(totalUsed)} of {TOTAL_GB} GB used</span>
        </div>
        <div className="h-1.5 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-full" style={{ width: `${percentage}%` }} />
        </div>
      </div>
    </div>
  );
}
