import { useState, useRef, useEffect, useCallback } from 'react';
import { Send, MessageSquare } from 'lucide-react';
import { callGemini } from '@/lib/gemini';
import type { ChatMessage } from '@/lib/supabase';

interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
}

export default function ChatApp() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSession, setActiveSession] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const current = sessions.find((s) => s.id === activeSession);

  const scrollToBottom = useCallback(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, []);

  useEffect(() => { scrollToBottom(); }, [current?.messages, loading, scrollToBottom]);

  const newChat = () => {
    const id = crypto.randomUUID();
    setSessions([...sessions, { id, title: 'New Chat', messages: [] }]);
    setActiveSession(id);
  };

  const send = async () => {
    if (!input.trim() || !activeSession) return;
    const text = input.trim();
    setInput('');
    setLoading(true);

    const userMsg: ChatMessage = { role: 'user', content: text };
    setSessions(sessions.map((s) => s.id === activeSession ? {
      ...s, title: s.messages.length === 0 ? text.slice(0, 30) : s.title,
      messages: [...s.messages, userMsg]
    } : s));

    try {
      const session = sessions.find((s) => s.id === activeSession);
      const response = await callGemini([userMsg], session?.messages || []);
      setSessions(sessions.map((s) => s.id === activeSession ? { ...s, messages: [...s.messages, userMsg, { role: 'assistant', content: response }] } : s));
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Something went wrong';
      setSessions(sessions.map((s) => s.id === activeSession ? { ...s, messages: [...s.messages, { role: 'assistant', content: `Error: ${msg}` }] } : s));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      {/* Session list */}
      <div className="w-56 flex-shrink-0 border-r border-gray-200 dark:border-gray-800 p-3 hidden sm:block">
        <button onClick={newChat} className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-teal-500 text-white text-sm font-medium hover:bg-teal-600 mb-3"><MessageSquare className="w-4 h-4" /> New Chat</button>
        <div className="space-y-1 overflow-auto">
          {sessions.map((s) => (
            <button key={s.id} onClick={() => setActiveSession(s.id)} className={`w-full text-left px-3 py-2 rounded-lg text-sm truncate ${activeSession === s.id ? 'bg-teal-50 dark:bg-teal-950/30 text-teal-600 dark:text-teal-400 font-medium' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'}`}>{s.title}</button>
          ))}
        </div>
      </div>
      {/* Chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="p-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-200">{current?.title || 'Select or start a chat'}</h2>
          <button onClick={newChat} className="sm:hidden text-xs text-teal-500">New</button>
        </div>
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
          {!current ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <MessageSquare className="w-12 h-12 text-gray-300 dark:text-gray-700 mb-3" />
              <p className="text-sm text-gray-400">Start a new chat</p>
            </div>
          ) : current.messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center"><p className="text-sm text-gray-400">Send a message to begin</p></div>
          ) : (
            current.messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm ${msg.role === 'user' ? 'bg-teal-500 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-200'}`}>{msg.content}</div>
              </div>
            ))
          )}
          {loading && <div className="flex justify-start"><div className="bg-gray-100 dark:bg-gray-800 px-4 py-3 rounded-2xl"><div className="flex gap-1"><span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '0ms' }} /><span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '150ms' }} /><span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '300ms' }} /></div></div></div>}
        </div>
        <div className="p-3 border-t border-gray-200 dark:border-gray-800">
          <div className="flex gap-2">
            <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} disabled={!activeSession || loading} placeholder="Type a message..." className="flex-1 px-4 py-2.5 rounded-full bg-gray-100 dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 disabled:opacity-40" />
            <button onClick={send} disabled={!input.trim() || loading} className="w-10 h-10 rounded-full bg-teal-500 text-white flex items-center justify-center disabled:opacity-40 hover:bg-teal-600"><Send className="w-4 h-4" /></button>
          </div>
        </div>
      </div>
    </div>
  );
}
