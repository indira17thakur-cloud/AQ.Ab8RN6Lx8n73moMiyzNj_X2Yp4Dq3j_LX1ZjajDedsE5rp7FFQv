import { useState, useEffect, useCallback } from 'react';
import { supabase, type CalendarEvent } from '@/lib/supabase';
import { Plus, Trash2, X, ChevronLeft, ChevronRight, Clock } from 'lucide-react';

const COLOR_MAP: Record<string, string> = {
  blue: 'bg-blue-500',
  emerald: 'bg-emerald-500',
  amber: 'bg-amber-500',
  red: 'bg-red-500',
  purple: 'bg-purple-500',
};

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

export default function CalendarApp() {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTime, setNewTime] = useState('');
  const [newColor, setNewColor] = useState('blue');
  const [loading, setLoading] = useState(true);

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('calendar_events').select('*').order('event_time', { ascending: true });
    if (error) {
      console.error('Failed to load events:', error.message);
    } else {
      setEvents(data || []);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const addEvent = async () => {
    if (!newTitle.trim() || !selectedDate) return;
    const { data, error } = await supabase
      .from('calendar_events')
      .insert({ title: newTitle, event_date: selectedDate, event_time: newTime, color: newColor })
      .select('*')
      .single();
    if (error) {
      console.error('Failed to add event:', error.message);
      return;
    }
    setEvents([...events, data as CalendarEvent]);
    setNewTitle('');
    setNewTime('');
    setNewColor('blue');
    setShowAdd(false);
  };

  const deleteEvent = async (id: string) => {
    await supabase.from('calendar_events').delete().eq('id', id);
    setEvents(events.filter((e) => e.id !== id));
  };

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const dateStr = (day: number) => `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  const eventsForDate = (date: string) => events.filter((e) => e.event_date === date);
  const selectedEvents = selectedDate ? eventsForDate(selectedDate) : [];

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">
            {MONTHS[month]} {year}
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setCurrentMonth(new Date(year, month - 1, 1))} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
            <ChevronLeft className="w-4 h-4 text-gray-500" />
          </button>
          <button onClick={() => { setCurrentMonth(new Date()); setSelectedDate(new Date().toISOString().split('T')[0]); }} className="px-3 py-1 rounded-lg text-xs font-medium text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30">
            Today
          </button>
          <button onClick={() => setCurrentMonth(new Date(year, month + 1, 1))} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden flex-col lg:flex-row">
        {/* Calendar grid */}
        <div className="flex-1 p-4 overflow-auto">
          <div className="grid grid-cols-7 gap-1 mb-2">
            {DAYS.map((day) => (
              <div key={day} className="text-center text-xs font-medium text-gray-400 py-2">{day}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: firstDay }).map((_, i) => (
              <div key={`empty-${i}`} />
            ))}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const ds = dateStr(day);
              const dayEvents = eventsForDate(ds);
              const isToday = ds === new Date().toISOString().split('T')[0];
              const isSelected = ds === selectedDate;
              return (
                <button
                  key={day}
                  onClick={() => { setSelectedDate(ds); setShowAdd(false); }}
                  className={`min-h-[60px] sm:min-h-[80px] p-1.5 rounded-lg text-left transition-colors border ${
                    isSelected
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/30'
                      : 'border-transparent hover:bg-gray-50 dark:hover:bg-gray-800/50'
                  }`}
                >
                  <div className={`text-xs ${isToday ? 'bg-blue-500 text-white w-6 h-6 rounded-full flex items-center justify-center font-medium' : 'text-gray-600 dark:text-gray-300'}`}>
                    {day}
                  </div>
                  <div className="mt-1 space-y-0.5">
                    {dayEvents.slice(0, 2).map((ev) => (
                      <div key={ev.id} className={`text-[10px] px-1.5 py-0.5 rounded text-white truncate ${COLOR_MAP[ev.color] || 'bg-blue-500'}`}>
                        {ev.title}
                      </div>
                    ))}
                    {dayEvents.length > 2 && (
                      <div className="text-[10px] text-gray-400">+{dayEvents.length - 2} more</div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Day detail panel */}
        {selectedDate && (
          <div className="lg:w-80 border-t lg:border-t-0 lg:border-l border-gray-200 dark:border-gray-800 p-4 overflow-auto">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-200">
                {new Date(selectedDate + 'T00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
              </h3>
              <button onClick={() => setShowAdd(!showAdd)} className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                <Plus className="w-4 h-4 text-blue-500" />
              </button>
            </div>

            {showAdd && (
              <div className="mb-3 p-3 rounded-xl bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-gray-500">New Event</span>
                  <button onClick={() => setShowAdd(false)} className="p-1"><X className="w-3.5 h-3.5 text-gray-400" /></button>
                </div>
                <input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="Title" className="w-full px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
                <div className="flex gap-2">
                  <input value={newTime} onChange={(e) => setNewTime(e.target.value)} placeholder="Time" className="flex-1 px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
                  <select value={newColor} onChange={(e) => setNewColor(e.target.value)} className="px-2 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm">
                    <option value="blue">Blue</option><option value="emerald">Green</option><option value="amber">Amber</option><option value="red">Red</option><option value="purple">Purple</option>
                  </select>
                </div>
                <button onClick={addEvent} disabled={!newTitle.trim()} className="w-full py-2 rounded-lg bg-blue-500 text-white text-sm font-medium hover:bg-blue-600 disabled:opacity-40">Add</button>
              </div>
            )}

            {selectedEvents.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-8">No events</p>
            ) : (
              <div className="space-y-2">
                {selectedEvents.map((ev) => (
                  <div key={ev.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50 group">
                    <div className={`w-1 h-8 rounded-full ${COLOR_MAP[ev.color] || 'bg-blue-500'}`} />
                    <div className="flex-1">
                      {ev.event_time && <div className="text-xs text-gray-400 flex items-center gap-1"><Clock className="w-3 h-3" />{ev.event_time}</div>}
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-200">{ev.title}</div>
                    </div>
                    <button onClick={() => deleteEvent(ev.id)} className="opacity-0 group-hover:opacity-100 p-1"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
