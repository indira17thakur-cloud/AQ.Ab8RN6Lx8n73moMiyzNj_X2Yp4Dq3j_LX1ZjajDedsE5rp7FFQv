import { useState } from 'react';
import { Globe, ArrowRight, Copy } from 'lucide-react';

const LANGUAGES = [
  { code: 'en', name: 'English' }, { code: 'es', name: 'Spanish' }, { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' }, { code: 'hi', name: 'Hindi' }, { code: 'ja', name: 'Japanese' },
  { code: 'ko', name: 'Korean' }, { code: 'zh', name: 'Chinese' }, { code: 'ar', name: 'Arabic' },
  { code: 'pt', name: 'Portuguese' }, { code: 'ru', name: 'Russian' }, { code: 'it', name: 'Italian' },
];

export default function TranslateApp() {
  const [sourceLang, setSourceLang] = useState('en');
  const [targetLang, setTargetLang] = useState('es');
  const [sourceText, setSourceText] = useState('');
  const [translated, setTranslated] = useState('');
  const [loading, setLoading] = useState(false);

  const translate = async () => {
    if (!sourceText.trim()) return;
    setLoading(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/gemini-proxy`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}` },
        body: JSON.stringify({
          messages: [{ role: 'user', content: `Translate the following text from ${LANGUAGES.find(l => l.code === sourceLang)?.name} to ${LANGUAGES.find(l => l.code === targetLang)?.name}. Only provide the translation, nothing else.\n\nText: ${sourceText}` }],
          history: [],
        }),
      });
      if (!response.ok) throw new Error('Translation failed');
      const data = await response.json();
      setTranslated(data.response || 'Translation failed');
    } catch {
      setTranslated('Translation failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const swap = () => {
    const s = sourceLang; setSourceLang(targetLang); setTargetLang(s);
    const t = sourceText; setSourceText(translated); setTranslated(t);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="p-4 border-b border-gray-200 dark:border-gray-800 flex items-center gap-2">
        <Globe className="w-5 h-5 text-blue-400" />
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Translate</h2>
      </div>
      <div className="flex-1 overflow-auto p-4">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center gap-2 mb-4">
            <select value={sourceLang} onChange={(e) => setSourceLang(e.target.value)} className="flex-1 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-transparent text-sm text-gray-700 dark:text-gray-200">
              {LANGUAGES.map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}
            </select>
            <button onClick={swap} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"><ArrowRight className="w-4 h-4 text-gray-400" /></button>
            <select value={targetLang} onChange={(e) => setTargetLang(e.target.value)} className="flex-1 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-transparent text-sm text-gray-700 dark:text-gray-200">
              {LANGUAGES.map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
              <textarea value={sourceText} onChange={(e) => setSourceText(e.target.value)} placeholder="Enter text to translate..." className="w-full h-48 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 text-sm text-gray-700 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-400 resize-none" />
              <button onClick={translate} disabled={!sourceText.trim() || loading} className="mt-2 px-4 py-2 rounded-lg bg-blue-500 text-white text-sm font-medium hover:bg-blue-600 disabled:opacity-40">{loading ? 'Translating...' : 'Translate'}</button>
            </div>
            <div>
              <div className="relative">
                <textarea value={translated} readOnly placeholder="Translation will appear here..." className="w-full h-48 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-blue-50 dark:bg-blue-950/20 text-sm text-gray-700 dark:text-gray-200 focus:outline-none resize-none" />
                {translated && <button onClick={() => navigator.clipboard?.writeText(translated)} className="absolute top-2 right-2 p-2 rounded-full hover:bg-blue-100 dark:hover:bg-blue-900"><Copy className="w-4 h-4 text-gray-400" /></button>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
