import { useState } from 'react';
import { Phone, PhoneOff, Mic, MicOff, Volume2, Dialpad } from 'lucide-react';

export default function PhoneApp() {
  const [number, setNumber] = useState('');
  const [inCall, setInCall] = useState(false);
  const [muted, setMuted] = useState(false);

  const press = (digit: string) => {
    setNumber(number + digit);
  };

  if (inCall) {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-gradient-to-br from-blue-600 to-cyan-700 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-32 h-32 rounded-full bg-white/20 flex items-center justify-center mb-6 backdrop-blur-sm">
            <Phone className="w-14 h-14 text-white" />
          </div>
          <p className="text-white text-2xl font-light">{number || 'Unknown'}</p>
          <p className="text-blue-100 text-sm mt-2">Calling...</p>
        </div>
        <div className="p-6 flex items-center justify-center gap-4">
          <button onClick={() => setMuted(!muted)} className={`p-4 rounded-full ${muted ? 'bg-white' : 'bg-white/20'} transition-colors`}>
            {muted ? <MicOff className="w-6 h-6 text-blue-600" /> : <Mic className="w-6 h-6 text-white" />}
          </button>
          <button onClick={() => { setInCall(false); setNumber(''); }} className="p-4 rounded-full bg-red-500 hover:bg-red-600 transition-colors">
            <PhoneOff className="w-6 h-6 text-white" />
          </button>
          <button className="p-4 rounded-full bg-white/20"><Volume2 className="w-6 h-6 text-white" /></button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="p-4 border-b border-gray-200 dark:border-gray-800"><h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Phone</h2></div>
      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-xs">
          <div className="text-center mb-6">
            <input value={number} onChange={(e) => setNumber(e.target.value.replace(/[^0-9*#]/g, ''))} placeholder="Enter a number" className="w-full text-center text-2xl font-light text-gray-700 dark:text-gray-200 bg-transparent focus:outline-none border-b border-gray-200 dark:border-gray-700 pb-2" />
          </div>
          <div className="grid grid-cols-3 gap-3">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((d) => (
              <button key={d} onClick={() => press(d)} className="aspect-square rounded-full bg-gray-100 dark:bg-gray-800 text-xl font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">{d}</button>
            ))}
          </div>
          <div className="mt-6 flex justify-center">
            <button onClick={() => number && setInCall(true)} disabled={!number} className="w-16 h-16 rounded-full bg-green-500 text-white flex items-center justify-center hover:bg-green-600 disabled:opacity-40 transition-colors">
              <Phone className="w-7 h-7" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
