import { useState, useEffect, useCallback } from 'react';
import { supabase, type Photo } from '@/lib/supabase';
import { Plus, Trash2, Images, X, Search } from 'lucide-react';

export default function PhotosApp() {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{ url: string; alt: string }[]>([]);
  const [searching, setSearching] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchPhotos = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('photos').select('*').order('created_at', { ascending: false });
    if (error) console.error('Failed:', error.message);
    else setPhotos(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchPhotos(); }, [fetchPhotos]);

  const searchPhotos = async () => {
    if (!searchQuery.trim()) return;
    setSearching(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/gemini-proxy`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}` },
        body: JSON.stringify({ action: 'photos', query: searchQuery }),
      });
      if (!response.ok) throw new Error('Search failed');
      const data = await response.json();
      setSearchResults(data.photos || []);
    } catch {
      console.error('Photo search failed');
    }
    setSearching(false);
  };

  const addPhoto = async (url: string, title: string) => {
    const { data, error } = await supabase.from('photos').insert({ title, image_url: url }).select('*').single();
    if (error) { console.error('Failed:', error.message); return; }
    setPhotos([data as Photo, ...photos]);
  };

  const deletePhoto = async (id: string) => {
    await supabase.from('photos').delete().eq('id', id);
    setPhotos(photos.filter((p) => p.id !== id));
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Photos</h2>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-purple-500 text-white text-sm font-medium hover:bg-purple-600"><Plus className="w-4 h-4" /> Add</button>
      </div>

      {showAdd && (
        <div className="p-4 border-b border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/30">
          <div className="flex items-center justify-between mb-2"><span className="text-xs font-medium text-gray-500">Search for photos</span><button onClick={() => { setShowAdd(false); setSearchResults([]); }}><X className="w-4 h-4 text-gray-400" /></button></div>
          <div className="flex gap-2 mb-3">
            <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && searchPhotos()} placeholder="Search (e.g. mountains, ocean)..." className="flex-1 px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400" />
            <button onClick={searchPhotos} disabled={searching} className="px-4 py-2 rounded-lg bg-purple-500 text-white text-sm font-medium hover:bg-purple-600 disabled:opacity-40">{searching ? '...' : 'Search'}</button>
          </div>
          {searchResults.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {searchResults.map((r, i) => (
                <button key={i} onClick={() => { addPhoto(r.url, r.alt || 'Photo'); }} className="relative group rounded-lg overflow-hidden">
                  <img src={r.url} alt={r.alt} className="w-full h-24 object-cover" />
                  <div className="absolute inset-0 bg-purple-500/0 group-hover:bg-purple-500/30 flex items-center justify-center transition-colors">
                    <Plus className="w-6 h-6 text-white opacity-0 group-hover:opacity-100" />
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="flex-1 overflow-auto p-4">
        {loading ? <div className="text-center text-sm text-gray-400 py-8">Loading...</div> :
         photos.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Images className="w-12 h-12 text-gray-300 dark:text-gray-700 mb-3" />
            <p className="text-sm text-gray-400">No photos yet</p>
            <p className="text-xs text-gray-300 dark:text-gray-600 mt-1">Click Add to search and add photos</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {photos.map((photo) => (
              <div key={photo.id} className="group relative rounded-xl overflow-hidden">
                <img src={photo.image_url} alt={photo.title} className="w-full h-40 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-3">
                  <span className="text-xs text-white truncate">{photo.title}</span>
                  <button onClick={() => deletePhoto(photo.id)} className="absolute top-2 right-2 p-1.5 rounded-full bg-black/40 hover:bg-red-500 transition-colors"><Trash2 className="w-3.5 h-3.5 text-white" /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
