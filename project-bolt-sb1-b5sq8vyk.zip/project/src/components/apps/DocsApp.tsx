import { useState, useEffect, useCallback } from 'react';
import { supabase, type Document } from '@/lib/supabase';
import { Plus, Trash2, FileText, Search } from 'lucide-react';

export default function DocsApp() {
  const [docs, setDocs] = useState<Document[]>([]);
  const [editing, setEditing] = useState<Document | null>(null);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const fetchDocs = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('documents').select('*').order('updated_at', { ascending: false });
    if (error) console.error('Failed:', error.message);
    else setDocs(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchDocs(); }, [fetchDocs]);

  const createDoc = async () => {
    const { data, error } = await supabase.from('documents').insert({ title: 'Untitled document', content: '' }).select('*').single();
    if (error) { console.error('Failed:', error.message); return; }
    const newDoc = data as Document;
    setDocs([newDoc, ...docs]);
    setEditing(newDoc);
    setTitle(newDoc.title);
    setContent(newDoc.content);
  };

  const saveDoc = async () => {
    if (!editing) return;
    const { error } = await supabase.from('documents').update({ title, content, updated_at: new Date().toISOString() }).eq('id', editing.id);
    if (error) { console.error('Failed:', error.message); return; }
    setDocs(docs.map((d) => d.id === editing.id ? { ...d, title, content, updated_at: new Date().toISOString() } : d));
    setEditing(null);
  };

  const deleteDoc = async (id: string) => {
    await supabase.from('documents').delete().eq('id', id);
    setDocs(docs.filter((d) => d.id !== id));
    if (editing?.id === id) setEditing(null);
  };

  const openDoc = (doc: Document) => {
    setEditing(doc);
    setTitle(doc.title);
    setContent(doc.content);
  };

  const filtered = docs.filter((d) => d.title.toLowerCase().includes(search.toLowerCase()));

  if (editing) {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-800">
          <input value={title} onChange={(e) => setTitle(e.target.value)} className="flex-1 px-3 py-2 bg-transparent text-sm font-medium text-gray-700 dark:text-gray-200 focus:outline-none" />
          <div className="flex gap-2">
            <button onClick={saveDoc} className="px-4 py-2 rounded-lg bg-blue-500 text-white text-sm font-medium hover:bg-blue-600">Save</button>
            <button onClick={() => setEditing(null)} className="px-3 py-2 rounded-lg text-sm text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800">Close</button>
          </div>
        </div>
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Start writing..."
          className="flex-1 p-6 lg:p-12 bg-transparent text-gray-700 dark:text-gray-200 focus:outline-none resize-none text-base leading-relaxed max-w-3xl mx-auto w-full"
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Documents</h2>
        <button onClick={createDoc} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-500 text-white text-sm font-medium hover:bg-blue-600">
          <Plus className="w-4 h-4" /> New
        </button>
      </div>
      <div className="p-4 border-b border-gray-200 dark:border-gray-800">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search documents..." className="w-full pl-9 pr-4 py-2 rounded-full bg-gray-100 dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
        </div>
      </div>
      <div className="flex-1 overflow-auto p-4">
        {loading ? <div className="text-center text-sm text-gray-400 py-8">Loading...</div> :
         filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <FileText className="w-12 h-12 text-gray-300 dark:text-gray-700 mb-3" />
            <p className="text-sm text-gray-400">No documents yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filtered.map((doc) => (
              <div key={doc.id} onClick={() => openDoc(doc)} className="group p-4 rounded-xl border border-gray-200 dark:border-gray-700 hover:shadow-md cursor-pointer transition-all">
                <FileText className="w-8 h-8 text-blue-400 mb-2" />
                <div className="text-sm font-medium text-gray-700 dark:text-gray-200 truncate">{doc.title}</div>
                <div className="text-xs text-gray-400 truncate mt-1">{doc.content.slice(0, 60) || 'Empty document'}</div>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-xs text-gray-400">{new Date(doc.updated_at).toLocaleDateString()}</span>
                  <button onClick={(e) => { e.stopPropagation(); deleteDoc(doc.id); }} className="opacity-0 group-hover:opacity-100 p-1"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
