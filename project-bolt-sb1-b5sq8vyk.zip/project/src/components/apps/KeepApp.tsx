import { useState, useEffect, useCallback } from 'react';
import { supabase, type Note } from '@/lib/supabase';
import { Plus, Trash2, X } from 'lucide-react';

const COLORS: Record<string, string> = {
  amber: 'bg-amber-100 dark:bg-amber-900/40',
  blue: 'bg-blue-100 dark:bg-blue-900/40',
  green: 'bg-green-100 dark:bg-green-900/40',
  pink: 'bg-pink-100 dark:bg-pink-900/40',
  purple: 'bg-purple-100 dark:bg-purple-900/40',
};

export default function KeepApp() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newColor, setNewColor] = useState('amber');
  const [loading, setLoading] = useState(true);

  const fetchNotes = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('notes').select('*').order('created_at', { ascending: false });
    if (error) console.error('Failed:', error.message);
    else setNotes(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchNotes(); }, [fetchNotes]);

  const addNote = async () => {
    if (!newTitle.trim() && !newContent.trim()) return;
    const { data, error } = await supabase.from('notes').insert({ title: newTitle, content: newContent, color: newColor }).select('*').single();
    if (error) { console.error('Failed:', error.message); return; }
    setNotes([data as Note, ...notes]);
    setNewTitle(''); setNewContent(''); setNewColor('amber'); setShowAdd(false);
  };

  const deleteNote = async (id: string) => {
    await supabase.from('notes').delete().eq('id', id);
    setNotes(notes.filter((n) => n.id !== id));
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Keep</h2>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-white text-sm font-medium hover:bg-amber-600"><Plus className="w-4 h-4" /> New Note</button>
      </div>

      {showAdd && (
        <div className="p-4 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
          <div className="max-w-md mx-auto space-y-2">
            <div className="flex items-center justify-between"><span className="text-xs font-medium text-gray-500">New Note</span><button onClick={() => setShowAdd(false)}><X className="w-4 h-4 text-gray-400" /></button></div>
            <input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="Title" className="w-full px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" />
            <textarea value={newContent} onChange={(e) => setNewContent(e.target.value)} placeholder="Take a note..." className="w-full px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 min-h-[80px] resize-none" />
            <div className="flex items-center justify-between">
              <select value={newColor} onChange={(e) => setNewColor(e.target.value)} className="px-2 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-transparent text-sm text-gray-600 dark:text-gray-300">
                <option value="amber">Amber</option><option value="blue">Blue</option><option value="green">Green</option><option value="pink">Pink</option><option value="purple">Purple</option>
              </select>
              <button onClick={addNote} className="px-4 py-2 rounded-lg bg-amber-500 text-white text-sm font-medium hover:bg-amber-600">Add</button>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-auto p-4">
        {loading ? <div className="text-center text-sm text-gray-400 py-8">Loading...</div> :
         notes.length === 0 ? <div className="flex flex-col items-center justify-center h-full text-center"><p className="text-sm text-gray-400">No notes yet</p></div> :
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 max-w-5xl mx-auto">
           {notes.map((note) => (
             <div key={note.id} className={`group p-4 rounded-xl ${COLORS[note.color] || COLORS.amber} relative min-h-[120px]`}>
               <div className="text-sm font-semibold text-gray-800 dark:text-gray-100 mb-1">{note.title}</div>
               <div className="text-sm text-gray-600 dark:text-gray-300 whitespace-pre-wrap">{note.content}</div>
               <button onClick={() => deleteNote(note.id)} className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-all"><Trash2 className="w-3.5 h-3.5 text-gray-600 dark:text-gray-300" /></button>
             </div>
           ))}
         </div>}
      </div>
    </div>
  );
}
