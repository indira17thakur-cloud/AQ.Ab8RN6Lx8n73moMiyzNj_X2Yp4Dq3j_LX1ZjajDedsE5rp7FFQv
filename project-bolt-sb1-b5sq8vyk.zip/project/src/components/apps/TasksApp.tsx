import { useState, useEffect, useCallback } from 'react';
import { supabase, type Task } from '@/lib/supabase';
import { Plus, Trash2, ListChecks, Circle, CheckCircle2 } from 'lucide-react';

export default function TasksApp() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTitle, setNewTitle] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchTasks = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('tasks').select('*').order('created_at', { ascending: false });
    if (error) console.error('Failed:', error.message);
    else setTasks(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchTasks(); }, [fetchTasks]);

  const addTask = async () => {
    if (!newTitle.trim()) return;
    const { data, error } = await supabase.from('tasks').insert({ title: newTitle }).select('*').single();
    if (error) { console.error('Failed:', error.message); return; }
    setTasks([data as Task, ...tasks]);
    setNewTitle('');
  };

  const toggleTask = async (task: Task) => {
    await supabase.from('tasks').update({ completed: !task.completed }).eq('id', task.id);
    setTasks(tasks.map((t) => t.id === task.id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTask = async (id: string) => {
    await supabase.from('tasks').delete().eq('id', id);
    setTasks(tasks.filter((t) => t.id !== id));
  };

  const completed = tasks.filter((t) => t.completed).length;

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="p-4 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Tasks</h2>
          <span className="text-xs text-gray-400">{completed}/{tasks.length} done</span>
        </div>
        <div className="flex gap-2">
          <input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && addTask()} placeholder="Add a task..." className="flex-1 px-4 py-2.5 rounded-full bg-gray-100 dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400" />
          <button onClick={addTask} disabled={!newTitle.trim()} className="w-10 h-10 rounded-full bg-emerald-500 text-white flex items-center justify-center disabled:opacity-40 hover:bg-emerald-600"><Plus className="w-4 h-4" /></button>
        </div>
      </div>
      <div className="flex-1 overflow-auto p-4">
        {loading ? <div className="text-center text-sm text-gray-400 py-8">Loading...</div> :
         tasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <ListChecks className="w-12 h-12 text-gray-300 dark:text-gray-700 mb-3" />
            <p className="text-sm text-gray-400">No tasks yet</p>
          </div>
        ) : (
          <div className="space-y-1 max-w-2xl mx-auto">
            {tasks.map((task) => (
              <div key={task.id} className="group flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                <button onClick={() => toggleTask(task)} className="flex-shrink-0">
                  {task.completed ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <Circle className="w-5 h-5 text-gray-300 dark:text-gray-600" />}
                </button>
                <span className={`flex-1 text-sm ${task.completed ? 'line-through text-gray-400' : 'text-gray-700 dark:text-gray-200'}`}>{task.title}</span>
                <button onClick={() => deleteTask(task.id)} className="opacity-0 group-hover:opacity-100 p-1"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
