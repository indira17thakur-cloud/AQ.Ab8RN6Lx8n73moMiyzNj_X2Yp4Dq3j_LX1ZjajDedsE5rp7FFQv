import { useState, useEffect, useCallback } from 'react';
import { supabase, type Email as EmailType } from '@/lib/supabase';
import { PenSquare, Star, Trash2, Inbox, Send, FileEdit, Search, ArrowLeft, Archive } from 'lucide-react';

type Folder = 'inbox' | 'sent' | 'drafts' | 'trash';

export default function EmailApp() {
  const [emails, setEmails] = useState<EmailType[]>([]);
  const [folder, setFolder] = useState<Folder>('inbox');
  const [selected, setSelected] = useState<EmailType | null>(null);
  const [composing, setComposing] = useState(false);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [composeData, setComposeData] = useState({ recipient: '', subject: '', body: '' });

  const fetchEmails = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('emails')
      .select('*')
      .eq('folder', folder)
      .order('created_at', { ascending: false });
    if (error) {
      console.error('Failed to load emails:', error.message);
    } else {
      setEmails(data || []);
    }
    setLoading(false);
  }, [folder]);

  useEffect(() => {
    fetchEmails();
    setSelected(null);
  }, [fetchEmails]);

  const openEmail = async (email: EmailType) => {
    setSelected(email);
    if (!email.is_read) {
      await supabase.from('emails').update({ is_read: true }).eq('id', email.id);
      setEmails(emails.map((e) => (e.id === email.id ? { ...e, is_read: true } : e)));
    }
  };

  const toggleStar = async (email: EmailType, e: React.MouseEvent) => {
    e.stopPropagation();
    await supabase.from('emails').update({ is_starred: !email.is_starred }).eq('id', email.id);
    setEmails(emails.map((em) => (em.id === email.id ? { ...em, is_starred: !em.is_starred } : em)));
    if (selected?.id === email.id) {
      setSelected({ ...email, is_starred: !email.is_starred });
    }
  };

  const deleteEmail = async (email: EmailType, e: React.MouseEvent) => {
    e.stopPropagation();
    if (folder === 'trash') {
      await supabase.from('emails').delete().eq('id', email.id);
    } else {
      await supabase.from('emails').update({ folder: 'trash' }).eq('id', email.id);
    }
    setEmails(emails.filter((em) => em.id !== email.id));
    if (selected?.id === email.id) setSelected(null);
  };

  const sendEmail = async () => {
    if (!composeData.recipient.trim() || !composeData.subject.trim()) return;
    const { data, error } = await supabase
      .from('emails')
      .insert({
        sender: 'me@sit.app',
        recipient: composeData.recipient,
        subject: composeData.subject,
        body: composeData.body,
        folder: 'sent',
        is_read: true,
      })
      .select('*')
      .single();
    if (error) {
      console.error('Failed to send email:', error.message);
      return;
    }
    setComposeData({ recipient: '', subject: '', body: '' });
    setComposing(false);
    if (folder === 'sent') {
      setEmails([data as EmailType, ...emails]);
    }
  };

  const folders: { id: Folder; label: string; icon: typeof Inbox }[] = [
    { id: 'inbox', label: 'Inbox', icon: Inbox },
    { id: 'sent', label: 'Sent', icon: Send },
    { id: 'drafts', label: 'Drafts', icon: FileEdit },
    { id: 'trash', label: 'Trash', icon: Trash2 },
  ];

  const filtered = emails.filter(
    (e) =>
      e.subject.toLowerCase().includes(search.toLowerCase()) ||
      e.sender.toLowerCase().includes(search.toLowerCase()) ||
      e.body.toLowerCase().includes(search.toLowerCase())
  );

  const unreadCount = emails.filter((e) => !e.is_read).length;

  return (
    <div className="flex h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      {/* Sidebar */}
      <div className="w-48 flex-shrink-0 border-r border-gray-200 dark:border-gray-800 p-3 hidden sm:block">
        <button
          onClick={() => { setComposing(true); setSelected(null); }}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-gradient-to-r from-red-500 to-red-600 text-white text-sm font-medium hover:shadow-md transition-shadow mb-4"
        >
          <PenSquare className="w-4 h-4" />
          Compose
        </button>
        <div className="space-y-1">
          {folders.map((f) => (
            <button
              key={f.id}
              onClick={() => { setFolder(f.id); setComposing(false); setSelected(null); }}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                folder === f.id
                  ? 'bg-red-50 dark:bg-red-950/30 text-red-600 dark:text-red-400 font-medium'
                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <f.icon className="w-4 h-4" />
              <span className="flex-1 text-left">{f.label}</span>
              {f.id === 'inbox' && unreadCount > 0 && (
                <span className="text-xs bg-red-500 text-white px-1.5 rounded-full">{unreadCount}</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Email list / detail / compose */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Search bar */}
        <div className="p-3 border-b border-gray-200 dark:border-gray-800 flex items-center gap-2">
          {selected && (
            <button onClick={() => setSelected(null)} className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
              <ArrowLeft className="w-4 h-4 text-gray-500" />
            </button>
          )}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search mail..."
              className="w-full pl-9 pr-4 py-2 rounded-full bg-gray-100 dark:bg-gray-800 text-sm text-gray-700 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-red-400"
            />
          </div>
        </div>

        {/* Mobile folder tabs */}
        <div className="sm:hidden flex border-b border-gray-200 dark:border-gray-800 overflow-x-auto">
          {folders.map((f) => (
            <button
              key={f.id}
              onClick={() => { setFolder(f.id); setSelected(null); setComposing(false); }}
              className={`flex items-center gap-1.5 px-4 py-2 text-xs whitespace-nowrap ${
                folder === f.id ? 'text-red-500 border-b-2 border-red-500 font-medium' : 'text-gray-500'
              }`}
            >
              <f.icon className="w-3.5 h-3.5" />
              {f.label}
            </button>
          ))}
        </div>

        {/* Compose view */}
        {composing ? (
          <div className="flex-1 flex flex-col p-4 overflow-auto">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-200">New Message</h3>
              <button onClick={() => setComposing(false)} className="text-sm text-gray-400 hover:text-gray-600">Discard</button>
            </div>
            <div className="space-y-2 flex-1 flex flex-col">
              <input
                value={composeData.recipient}
                onChange={(e) => setComposeData({ ...composeData, recipient: e.target.value })}
                placeholder="To"
                className="w-full px-3 py-2 border-b border-gray-200 dark:border-gray-700 bg-transparent text-sm text-gray-700 dark:text-gray-200 focus:outline-none focus:border-red-400"
              />
              <input
                value={composeData.subject}
                onChange={(e) => setComposeData({ ...composeData, subject: e.target.value })}
                placeholder="Subject"
                className="w-full px-3 py-2 border-b border-gray-200 dark:border-gray-700 bg-transparent text-sm text-gray-700 dark:text-gray-200 focus:outline-none focus:border-red-400"
              />
              <textarea
                value={composeData.body}
                onChange={(e) => setComposeData({ ...composeData, body: e.target.value })}
                placeholder="Write your message..."
                className="flex-1 w-full px-3 py-2 bg-transparent text-sm text-gray-700 dark:text-gray-200 focus:outline-none resize-none min-h-[200px]"
              />
              <div className="flex justify-end">
                <button
                  onClick={sendEmail}
                  disabled={!composeData.recipient.trim() || !composeData.subject.trim()}
                  className="px-6 py-2 rounded-lg bg-gradient-to-r from-red-500 to-red-600 text-white text-sm font-medium hover:shadow-md disabled:opacity-40 transition-all"
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        ) : selected ? (
          /* Email detail view */
          <div className="flex-1 overflow-auto p-4 sm:p-6">
            <div className="max-w-2xl mx-auto">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">{selected.subject}</h2>
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-200 dark:border-gray-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-400 to-red-600 flex items-center justify-center text-white font-medium text-sm">
                    {selected.sender.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-700 dark:text-gray-200">{selected.sender}</div>
                    <div className="text-xs text-gray-400">to {selected.recipient}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={(e) => toggleStar(selected, e)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                    <Star className={`w-4 h-4 ${selected.is_starred ? 'fill-amber-400 text-amber-400' : 'text-gray-400'}`} />
                  </button>
                  <button onClick={(e) => deleteEmail(selected, e)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                    <Trash2 className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">
                {selected.body || '(no content)'}
              </div>
            </div>
          </div>
        ) : (
          /* Email list */
          <div className="flex-1 overflow-auto">
            {loading ? (
              <div className="p-8 text-center text-sm text-gray-400">Loading...</div>
            ) : filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full p-8 text-center">
                <Inbox className="w-12 h-12 text-gray-300 dark:text-gray-700 mb-3" />
                <p className="text-sm text-gray-400">
                  {folder === 'inbox' ? 'No emails in your inbox' : `No emails in ${folder}`}
                </p>
                <button
                  onClick={() => setComposing(true)}
                  className="mt-3 text-sm text-red-500 hover:underline sm:hidden"
                >
                  Compose new email
                </button>
              </div>
            ) : (
              <div className="divide-y divide-gray-100 dark:divide-gray-800">
                {filtered.map((email) => (
                  <div
                    key={email.id}
                    onClick={() => openEmail(email)}
                    className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer transition-colors group"
                  >
                    <button onClick={(e) => toggleStar(email, e)} className="flex-shrink-0">
                      <Star className={`w-4 h-4 ${email.is_starred ? 'fill-amber-400 text-amber-400' : 'text-gray-300 dark:text-gray-600'}`} />
                    </button>
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${email.is_read ? 'bg-transparent' : 'bg-red-500'}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline gap-2">
                        <span className={`text-sm truncate ${email.is_read ? 'text-gray-600 dark:text-gray-300' : 'text-gray-900 dark:text-white font-semibold'}`}>
                          {folder === 'sent' ? email.recipient : email.sender}
                        </span>
                      </div>
                      <div className={`text-sm truncate ${email.is_read ? 'text-gray-500 dark:text-gray-400' : 'text-gray-700 dark:text-gray-200 font-medium'}`}>
                        {email.subject}
                      </div>
                      <div className="text-xs text-gray-400 truncate">{email.body}</div>
                    </div>
                    <button
                      onClick={(e) => deleteEmail(email, e)}
                      className="opacity-0 group-hover:opacity-100 p-1.5 rounded-full hover:bg-red-50 dark:hover:bg-red-950/40 transition-all flex-shrink-0"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-red-400" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
