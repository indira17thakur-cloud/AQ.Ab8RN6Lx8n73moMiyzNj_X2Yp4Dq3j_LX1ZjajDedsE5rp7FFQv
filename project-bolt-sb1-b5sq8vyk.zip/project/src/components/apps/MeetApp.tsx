import { useState, useEffect, useCallback } from 'react';
import { Video, Plus, Users, Copy, Phone } from 'lucide-react';

interface Meeting {
  id: string;
  code: string;
  title: string;
  created_at: string;
}

function generateCode() {
  const chars = 'abcdefghijklmnopqrstuvwxyz';
  return Array.from({ length: 3 }, () => chars[Math.floor(Math.random() * 26)] + chars[Math.floor(Math.random() * 26)] + chars[Math.floor(Math.random() * 26)]).join('-');
}

export default function MeetApp() {
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [inMeeting, setInMeeting] = useState(false);
  const [meetingCode, setMeetingCode] = useState('');

  useEffect(() => {
    const stored = localStorage.getItem('sit-meetings');
    if (stored) setMeetings(JSON.parse(stored));
  }, []);

  const saveMeetings = (m: Meeting[]) => {
    setMeetings(m);
    localStorage.setItem('sit-meetings', JSON.stringify(m));
  };

  const startInstantMeeting = () => {
    const code = generateCode();
    const meeting: Meeting = { id: crypto.randomUUID(), code, title: 'Instant Meeting', created_at: new Date().toISOString() };
    saveMeetings([meeting, ...meetings]);
    setMeetingCode(code);
    setInMeeting(true);
  };

  const joinMeeting = () => {
    if (!meetingCode.trim()) return;
    setInMeeting(true);
  };

  if (inMeeting) {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="flex-1 flex items-center justify-center relative">
          <div className="text-center">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-green-400 to-teal-600 flex items-center justify-center mb-4 mx-auto shadow-xl">
              <Video className="w-16 h-16 text-white" />
            </div>
            <p className="text-white text-lg font-medium">Meeting Code: {meetingCode}</p>
            <p className="text-gray-400 text-sm mt-1">Waiting for others to join...</p>
          </div>
        </div>
        <div className="p-4 flex items-center justify-center gap-3 border-t border-gray-800">
          <button className="p-3 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors"><Phone className="w-5 h-5 text-white" /></button>
          <button className="p-3 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors"><Video className="w-5 h-5 text-white" /></button>
          <button onClick={() => setInMeeting(false)} className="px-6 py-3 rounded-full bg-red-500 text-white text-sm font-medium hover:bg-red-600">Leave Meeting</button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="p-4 border-b border-gray-200 dark:border-gray-800">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Meet</h2>
      </div>
      <div className="flex-1 overflow-auto p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
          <button onClick={startInstantMeeting} className="flex flex-col items-center justify-center gap-3 p-8 rounded-2xl border-2 border-green-500/20 hover:border-green-500 hover:bg-green-50 dark:hover:bg-green-950/20 transition-all">
            <div className="w-14 h-14 rounded-full bg-green-500 flex items-center justify-center"><Video className="w-7 h-7 text-white" /></div>
            <div className="text-sm font-medium text-gray-700 dark:text-gray-200">New Meeting</div>
            <div className="text-xs text-gray-400">Start an instant meeting</div>
          </button>
          <div className="flex flex-col items-center justify-center gap-3 p-8 rounded-2xl border-2 border-gray-200 dark:border-gray-700">
            <div className="w-14 h-14 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center"><Users className="w-7 h-7 text-gray-400" /></div>
            <div className="text-sm font-medium text-gray-700 dark:text-gray-200">Join Meeting</div>
            <div className="flex gap-2 w-full">
              <input value={meetingCode} onChange={(e) => setMeetingCode(e.target.value)} placeholder="Enter code" className="flex-1 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-green-400" />
              <button onClick={joinMeeting} disabled={!meetingCode.trim()} className="px-3 py-2 rounded-lg bg-green-500 text-white text-sm font-medium hover:bg-green-600 disabled:opacity-40">Join</button>
            </div>
          </div>
        </div>
        {meetings.length > 0 && (
          <div className="mt-6 max-w-2xl mx-auto">
            <h3 className="text-xs font-medium text-gray-400 uppercase tracking-wide mb-2">Recent Meetings</h3>
            <div className="space-y-2">
              {meetings.map((m) => (
                <div key={m.id} className="flex items-center justify-between p-3 rounded-lg border border-gray-200 dark:border-gray-700">
                  <div><div className="text-sm font-medium text-gray-700 dark:text-gray-200">{m.title}</div><div className="text-xs text-gray-400">Code: {m.code}</div></div>
                  <div className="flex gap-2">
                    <button onClick={() => { navigator.clipboard?.writeText(m.code); }} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"><Copy className="w-4 h-4 text-gray-400" /></button>
                    <button onClick={() => { setMeetingCode(m.code); setInMeeting(true); }} className="px-3 py-1.5 rounded-lg bg-green-500 text-white text-xs font-medium hover:bg-green-600">Rejoin</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
