import { useState, useEffect, useCallback } from 'react';
import { supabase, type Document } from '@/lib/supabase';
import { BookOpen, Plus, Trash2, Search } from 'lucide-react';

export default function BooksApp() {
  const [books, setBooks] = useState<Document[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchBooks = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('documents').select('*').ilike('title', '%').order('updated_at', { ascending: false });
    if (error) console.error('Failed:', error.message);
    else setBooks(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchBooks(); }, [fetchBooks]);

  const addBook = async () => {
    const { data, error } = await supabase.from('documents').insert({ title: 'New Book', content: 'Once upon a time...' }).select('*').single();
    if (error) { console.error('Failed:', error.message); return; }
    setBooks([data as Document, ...books]);
  };

  const deleteBook = async (id: string) => {
    await supabase.from('documents').delete().eq('id', id);
    setBooks(books.filter((b) => b.id !== id));
  };

  const filtered = books.filter((b) => b.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Books</h2>
        <button onClick={addBook} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-orange-500 text-white text-sm font-medium hover:bg-orange-600"><Plus className="w-4 h-4" /> New</button>
      </div>
      <div className="p-4 border-b border-gray-200 dark:border-gray-800">
        <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search books..." className="w-full pl-9 pr-4 py-2 rounded-full bg-gray-100 dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" /></div>
      </div>
      <div className="flex-1 overflow-auto p-4">
        {loading ? <div className="text-center text-sm text-gray-400 py-8">Loading...</div> :
         filtered.length === 0 ? <div className="flex flex-col items-center justify-center h-full text-center"><BookOpen className="w-12 h-12 text-gray-300 dark:text-gray-700 mb-3" /><p className="text-sm text-gray-400">No books yet</p></div> :
         <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 max-w-4xl mx-auto">
           {filtered.map((book) => (
             <div key={book.id} className="group relative">
               <div className="aspect-[3/4] rounded-lg bg-gradient-to-br from-orange-100 to-red-100 dark:from-orange-900/40 dark:to-red-900/40 border border-orange-200 dark:border-orange-800 p-4 flex flex-col justify-between hover:shadow-md transition-all cursor-pointer">
                 <BookOpen className="w-6 h-6 text-orange-500" />
                 <div><div className="text-sm font-medium text-gray-700 dark:text-gray-200 line-clamp-2">{book.title}</div><div className="text-xs text-gray-400 mt-1">{book.content.slice(0, 40)}...</div></div>
               </div>
               <button onClick={() => deleteBook(book.id)} className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 p-1.5 rounded-full bg-white dark:bg-gray-800 shadow-sm"><Trash2 className="w-3 h-3 text-red-400" /></button>
             </div>
           ))}
         </div>}
      </div>
    </div>
  );
}
