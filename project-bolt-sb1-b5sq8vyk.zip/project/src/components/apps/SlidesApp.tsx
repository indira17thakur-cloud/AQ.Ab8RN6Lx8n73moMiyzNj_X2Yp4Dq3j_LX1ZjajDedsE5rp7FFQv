import { useState, useEffect, useCallback } from 'react';
import { supabase, type Presentation } from '@/lib/supabase';
import { Plus, Trash2, Presentation, ChevronLeft, ChevronRight } from 'lucide-react';

export default function SlidesApp() {
  const [decks, setDecks] = useState<Presentation[]>([]);
  const [editing, setEditing] = useState<Presentation | null>(null);
  const [slides, setSlides] = useState<{ title: string; content: string }[]>([]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchDecks = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('presentations').select('*').order('updated_at', { ascending: false });
    if (error) console.error('Failed:', error.message);
    else setDecks(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchDecks(); }, [fetchDecks]);

  const createDeck = async () => {
    const initialSlides = [{ title: 'Title Slide', content: 'Click to edit' }];
    const { data, error } = await supabase.from('presentations').insert({ title: 'Untitled presentation', slides: initialSlides }).select('*').single();
    if (error) { console.error('Failed:', error.message); return; }
    const newDeck = data as Presentation;
    setDecks([newDeck, ...decks]);
    setEditing(newDeck);
    setSlides(initialSlides);
    setCurrentSlide(0);
  };

  const openDeck = (deck: Presentation) => {
    setEditing(deck);
    setSlides(deck.slides || []);
    setCurrentSlide(0);
  };

  const saveDeck = async () => {
    if (!editing) return;
    await supabase.from('presentations').update({ slides, title: editing.title, updated_at: new Date().toISOString() }).eq('id', editing.id);
    setDecks(decks.map((d) => d.id === editing.id ? { ...d, slides, title: editing.title, updated_at: new Date().toISOString() } : d));
    setEditing(null);
  };

  const deleteDeck = async (id: string) => {
    await supabase.from('presentations').delete().eq('id', id);
    setDecks(decks.filter((d) => d.id !== id));
    if (editing?.id === id) setEditing(null);
  };

  const updateSlide = (field: 'title' | 'content', value: string) => {
    setSlides(slides.map((s, i) => i === currentSlide ? { ...s, [field]: value } : s));
  };

  const addSlide = () => {
    setSlides([...slides, { title: 'New Slide', content: '' }]);
    setCurrentSlide(slides.length);
  };

  if (editing) {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-800">
          <input value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} className="flex-1 px-3 py-2 bg-transparent text-sm font-medium text-gray-700 dark:text-gray-200 focus:outline-none" />
          <div className="flex gap-2">
            <button onClick={saveDeck} className="px-4 py-2 rounded-lg bg-amber-500 text-white text-sm font-medium hover:bg-amber-600">Save</button>
            <button onClick={() => setEditing(null)} className="px-3 py-2 rounded-lg text-sm text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800">Close</button>
          </div>
        </div>
        <div className="flex flex-1 overflow-hidden">
          {/* Slide thumbnails */}
          <div className="w-32 lg:w-40 border-r border-gray-200 dark:border-gray-800 overflow-auto p-2 space-y-2 flex-shrink-0">
            {slides.map((s, i) => (
              <button key={i} onClick={() => setCurrentSlide(i)} className={`w-full aspect-video rounded-lg border-2 p-2 text-left ${i === currentSlide ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/20' : 'border-gray-200 dark:border-gray-700'}`}>
                <div className="text-[10px] font-medium text-gray-700 dark:text-gray-300 truncate">{s.title}</div>
              </button>
            ))}
            <button onClick={addSlide} className="w-full aspect-video rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 flex items-center justify-center"><Plus className="w-4 h-4 text-gray-400" /></button>
          </div>
          {/* Slide editor */}
          <div className="flex-1 flex flex-col p-4 lg:p-8 overflow-auto">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs text-gray-400">Slide {currentSlide + 1} of {slides.length}</span>
              <div className="flex gap-2">
                <button onClick={() => setCurrentSlide(Math.max(0, currentSlide - 1))} className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"><ChevronLeft className="w-4 h-4 text-gray-500" /></button>
                <button onClick={() => setCurrentSlide(Math.min(slides.length - 1, currentSlide + 1))} className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"><ChevronRight className="w-4 h-4 text-gray-500" /></button>
              </div>
            </div>
            <div className="flex-1 bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6 lg:p-10 flex flex-col">
              <input value={slides[currentSlide]?.title || ''} onChange={(e) => updateSlide('title', e.target.value)} className="text-2xl font-semibold text-gray-800 dark:text-gray-100 bg-transparent focus:outline-none mb-4" />
              <textarea value={slides[currentSlide]?.content || ''} onChange={(e) => updateSlide('content', e.target.value)} className="flex-1 text-base text-gray-600 dark:text-gray-300 bg-transparent focus:outline-none resize-none" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Presentations</h2>
        <button onClick={createDeck} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-white text-sm font-medium hover:bg-amber-600"><Plus className="w-4 h-4" /> New</button>
      </div>
      <div className="flex-1 overflow-auto p-4">
        {loading ? <div className="text-center text-sm text-gray-400 py-8">Loading...</div> :
         decks.length === 0 ? <div className="flex flex-col items-center justify-center h-full text-center"><Presentation className="w-12 h-12 text-gray-300 dark:text-gray-700 mb-3" /><p className="text-sm text-gray-400">No presentations yet</p></div> :
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
           {decks.map((d) => (
             <div key={d.id} onClick={() => openDeck(d)} className="group p-4 rounded-xl border border-gray-200 dark:border-gray-700 hover:shadow-md cursor-pointer transition-all">
               <Presentation className="w-8 h-8 text-amber-500 mb-2" />
               <div className="text-sm font-medium text-gray-700 dark:text-gray-200 truncate">{d.title}</div>
               <div className="text-xs text-gray-400 mt-1">{d.slides?.length || 0} slides</div>
               <div className="flex items-center justify-between mt-3"><span className="text-xs text-gray-400">{new Date(d.updated_at).toLocaleDateString()}</span><button onClick={(e) => { e.stopPropagation(); deleteDeck(d.id); }} className="opacity-0 group-hover:opacity-100 p-1"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button></div>
             </div>
           ))}
         </div>}
      </div>
    </div>
  );
}
