import { useState, useEffect, useCallback } from 'react';
import { supabase, type Contact } from '@/lib/supabase';
import { Plus, Trash2, Search, Mail, Phone, Building2, X, User } from 'lucide-react';

export default function ContactsApp() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', email: '', phone: '', company: '' });
  const [loading, setLoading] = useState(true);

  const fetchContacts = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('contacts').select('*').order('name', { ascending: true });
    if (error) console.error('Failed:', error.message);
    else setContacts(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchContacts(); }, [fetchContacts]);

  const addContact = async () => {
    if (!newContact.name.trim()) return;
    const { data, error } = await supabase.from('contacts').insert(newContact).select('*').single();
    if (error) { console.error('Failed:', error.message); return; }
    setContacts([...contacts, data as Contact].sort((a, b) => a.name.localeCompare(b.name)));
    setNewContact({ name: '', email: '', phone: '', company: '' });
    setShowAdd(false);
  };

  const deleteContact = async (id: string) => {
    await supabase.from('contacts').delete().eq('id', id);
    setContacts(contacts.filter((c) => c.id !== id));
  };

  const filtered = contacts.filter((c) => c.name.toLowerCase().includes(search.toLowerCase()) || c.email.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Contacts</h2>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-500 text-white text-sm font-medium hover:bg-blue-600"><Plus className="w-4 h-4" /> Add</button>
      </div>
      <div className="p-4 border-b border-gray-200 dark:border-gray-800">
        <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search contacts..." className="w-full pl-9 pr-4 py-2 rounded-full bg-gray-100 dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" /></div>
      </div>
      {showAdd && (
        <div className="p-4 border-b border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/30">
          <div className="flex items-center justify-between mb-2"><span className="text-xs font-medium text-gray-500">New Contact</span><button onClick={() => setShowAdd(false)}><X className="w-4 h-4 text-gray-400" /></button></div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input value={newContact.name} onChange={(e) => setNewContact({ ...newContact, name: e.target.value })} placeholder="Name" className="px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
            <input value={newContact.email} onChange={(e) => setNewContact({ ...newContact, email: e.target.value })} placeholder="Email" className="px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
            <input value={newContact.phone} onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })} placeholder="Phone" className="px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
            <input value={newContact.company} onChange={(e) => setNewContact({ ...newContact, company: e.target.value })} placeholder="Company" className="px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
          </div>
          <button onClick={addContact} disabled={!newContact.name.trim()} className="mt-2 w-full py-2 rounded-lg bg-blue-500 text-white text-sm font-medium hover:bg-blue-600 disabled:opacity-40">Add Contact</button>
        </div>
      )}
      <div className="flex-1 overflow-auto p-4">
        {loading ? <div className="text-center text-sm text-gray-400 py-8">Loading...</div> :
         filtered.length === 0 ? <div className="flex flex-col items-center justify-center h-full text-center"><User className="w-12 h-12 text-gray-300 dark:text-gray-700 mb-3" /><p className="text-sm text-gray-400">No contacts yet</p></div> :
         <div className="space-y-2 max-w-2xl mx-auto">
           {filtered.map((c) => (
             <div key={c.id} className="group flex items-center gap-3 p-3 rounded-xl border border-gray-200 dark:border-gray-700 hover:shadow-sm transition-all">
               <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-cyan-500 flex items-center justify-center text-white font-medium text-sm flex-shrink-0">{c.name.charAt(0).toUpperCase()}</div>
               <div className="flex-1 min-w-0">
                 <div className="text-sm font-medium text-gray-700 dark:text-gray-200">{c.name}</div>
                 <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 mt-0.5">
                   {c.email && <span className="flex items-center gap-1 text-xs text-gray-400 truncate"><Mail className="w-3 h-3" />{c.email}</span>}
                   {c.phone && <span className="flex items-center gap-1 text-xs text-gray-400 truncate"><Phone className="w-3 h-3" />{c.phone}</span>}
                   {c.company && <span className="flex items-center gap-1 text-xs text-gray-400 truncate"><Building2 className="w-3 h-3" />{c.company}</span>}
                 </div>
               </div>
               <button onClick={() => deleteContact(c.id)} className="opacity-0 group-hover:opacity-100 p-1"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
             </div>
           ))}
         </div>}
      </div>
    </div>
  );
}
