import { useState, useEffect, useCallback } from 'react';
import { supabase, type Spreadsheet } from '@/lib/supabase';
import { Plus, Trash2, Sheet, Search } from 'lucide-react';

export default function SheetsApp() {
  const [sheets, setSheets] = useState<Spreadsheet[]>([]);
  const [editing, setEditing] = useState<Spreadsheet | null>(null);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [grid, setGrid] = useState<string[][]>([]);

  const fetchSheets = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('spreadsheets').select('*').order('updated_at', { ascending: false });
    if (error) console.error('Failed:', error.message);
    else setSheets(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchSheets(); }, [fetchSheets]);

  const createSheet = async () => {
    const emptyGrid: string[][] = Array.from({ length: 10 }, () => Array.from({ length: 5 }, () => ''));
    const { data, error } = await supabase.from('spreadsheets').insert({ title: 'Untitled spreadsheet', data: emptyGrid }).select('*').single();
    if (error) { console.error('Failed:', error.message); return; }
    const newSheet = data as Spreadsheet;
    setSheets([newSheet, ...sheets]);
    setEditing(newSheet);
    setGrid(emptyGrid);
  };

  const openSheet = (sheet: Spreadsheet) => {
    setEditing(sheet);
    setGrid(sheet.data || Array.from({ length: 10 }, () => Array.from({ length: 5 }, () => '')));
  };

  const saveSheet = async () => {
    if (!editing) return;
    await supabase.from('spreadsheets').update({ data: grid, updated_at: new Date().toISOString() }).eq('id', editing.id);
    setSheets(sheets.map((s) => s.id === editing.id ? { ...s, data: grid, updated_at: new Date().toISOString() } : s));
    setEditing(null);
  };

  const deleteSheet = async (id: string) => {
    await supabase.from('spreadsheets').delete().eq('id', id);
    setSheets(sheets.filter((s) => s.id !== id));
    if (editing?.id === id) setEditing(null);
  };

  const updateCell = (r: number, c: number, value: string) => {
    const newGrid = grid.map((row, ri) => ri === r ? row.map((cell, ci) => ci === c ? value : cell) : row);
    setGrid(newGrid);
  };

  const cols = ['A', 'B', 'C', 'D', 'E'];
  const filtered = sheets.filter((s) => s.title.toLowerCase().includes(search.toLowerCase()));

  if (editing) {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-800">
          <input value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} className="flex-1 px-3 py-2 bg-transparent text-sm font-medium text-gray-700 dark:text-gray-200 focus:outline-none" />
          <div className="flex gap-2">
            <button onClick={saveSheet} className="px-4 py-2 rounded-lg bg-green-600 text-white text-sm font-medium hover:bg-green-700">Save</button>
            <button onClick={() => setEditing(null)} className="px-3 py-2 rounded-lg text-sm text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800">Close</button>
          </div>
        </div>
        <div className="flex-1 overflow-auto">
          <table className="border-collapse">
            <thead>
              <tr>
                <th className="w-10 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-xs text-gray-400 font-normal"></th>
                {cols.map((c) => (
                  <th key={c} className="w-32 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-xs text-gray-400 font-normal p-1 text-center">{c}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {grid.map((row, ri) => (
                <tr key={ri}>
                  <td className="border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-xs text-gray-400 text-center p-1">{ri + 1}</td>
                  {row.map((cell, ci) => (
                    <td key={ci} className="border border-gray-200 dark:border-gray-700 p-0">
                      <input
                        value={cell}
                        onChange={(e) => updateCell(ri, ci, e.target.value)}
                        className="w-full h-8 px-2 bg-transparent text-sm text-gray-700 dark:text-gray-200 focus:outline-none focus:ring-1 focus:ring-green-400 focus:bg-green-50 dark:focus:bg-green-950/20"
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Spreadsheets</h2>
        <button onClick={createSheet} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-600 text-white text-sm font-medium hover:bg-green-700"><Plus className="w-4 h-4" /> New</button>
      </div>
      <div className="p-4 border-b border-gray-200 dark:border-gray-800">
        <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search..." className="w-full pl-9 pr-4 py-2 rounded-full bg-gray-100 dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-green-400" /></div>
      </div>
      <div className="flex-1 overflow-auto p-4">
        {loading ? <div className="text-center text-sm text-gray-400 py-8">Loading...</div> :
         filtered.length === 0 ? <div className="flex flex-col items-center justify-center h-full text-center"><Sheet className="w-12 h-12 text-gray-300 dark:text-gray-700 mb-3" /><p className="text-sm text-gray-400">No spreadsheets yet</p></div> :
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
           {filtered.map((s) => (
             <div key={s.id} onClick={() => openSheet(s)} className="group p-4 rounded-xl border border-gray-200 dark:border-gray-700 hover:shadow-md cursor-pointer transition-all">
               <Sheet className="w-8 h-8 text-green-500 mb-2" />
               <div className="text-sm font-medium text-gray-700 dark:text-gray-200 truncate">{s.title}</div>
               <div className="flex items-center justify-between mt-3"><span className="text-xs text-gray-400">{new Date(s.updated_at).toLocaleDateString()}</span><button onClick={(e) => { e.stopPropagation(); deleteSheet(s.id); }} className="opacity-0 group-hover:opacity-100 p-1"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button></div>
             </div>
           ))}
         </div>}
      </div>
    </div>
  );
}
