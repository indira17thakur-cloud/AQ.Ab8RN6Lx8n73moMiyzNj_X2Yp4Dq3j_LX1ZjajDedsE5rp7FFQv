import { useState, useEffect, useCallback } from 'react';
import { CalendarDays, Plus, Trash2, X } from 'lucide-react';
import { supabase, type CalendarEvent } from '@/lib/supabase';

const COLOR_MAP: Record<string, string> = {
  blue: 'bg-blue-500',
  emerald: 'bg-emerald-500',
  amber: 'bg-amber-500',
  red: 'bg-red-500',
  purple: 'bg-purple-500',
};

export default function CalendarWidget() {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTime, setNewTime] = useState('');
  const [newColor, setNewColor] = useState('blue');

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('calendar_events')
      .select('*')
      .eq('event_date', today)
      .order('event_time', { ascending: true });

    if (error) {
      console.error('Failed to load events:', error.message);
    } else {
      setEvents(data || []);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const addEvent = async () => {
    const title = newTitle.trim();
    if (!title) return;
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('calendar_events')
      .insert({ title, event_date: today, event_time: newTime.trim(), color: newColor })
      .select('*')
      .single();

    if (error) {
      console.error('Failed to add event:', error.message);
      return;
    }
    setEvents([...events, data as CalendarEvent].sort((a, b) => a.event_time.localeCompare(b.event_time)));
    setNewTitle('');
    setNewTime('');
    setNewColor('blue');
    setShowAdd(false);
  };

  const deleteEvent = async (id: string) => {
    const { error } = await supabase.from('calendar_events').delete().eq('id', id);
    if (error) {
      console.error('Failed to delete event:', error.message);
      return;
    }
    setEvents(events.filter((e) => e.id !== id));
  };

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <CalendarDays className="w-4 h-4 text-blue-500" />
          <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-200">Today's Schedule</h3>
        </div>
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          aria-label="Add event"
        >
          <Plus className="w-4 h-4 text-blue-500" />
        </button>
      </div>

      {showAdd && (
        <div className="mb-4 p-3 rounded-xl bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">New Event</span>
            <button onClick={() => setShowAdd(false)} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
              <X className="w-3.5 h-3.5 text-gray-400" />
            </button>
          </div>
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="Event title"
            className="w-full px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm text-gray-700 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
          <div className="flex gap-2">
            <input
              type="text"
              value={newTime}
              onChange={(e) => setNewTime(e.target.value)}
              placeholder="Time (e.g. 2:00 PM)"
              className="flex-1 px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm text-gray-700 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
            <select
              value={newColor}
              onChange={(e) => setNewColor(e.target.value)}
              className="px-2 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm text-gray-700 dark:text-gray-200 focus:outline-none"
            >
              <option value="blue">Blue</option>
              <option value="emerald">Green</option>
              <option value="amber">Amber</option>
              <option value="red">Red</option>
              <option value="purple">Purple</option>
            </select>
          </div>
          <button
            onClick={addEvent}
            disabled={!newTitle.trim()}
            className="w-full py-2 rounded-lg bg-blue-500 text-white text-sm font-medium hover:bg-blue-600 disabled:opacity-40 transition-colors"
          >
            Add Event
          </button>
        </div>
      )}

      {loading ? (
        <div className="py-8 text-center text-sm text-gray-400">Loading...</div>
      ) : events.length === 0 ? (
        <div className="py-8 text-center">
          <p className="text-sm text-gray-400 dark:text-gray-500">No events scheduled for today</p>
          <p className="text-xs text-gray-300 dark:text-gray-600 mt-1">Click + to add one</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {events.map((event) => (
            <div key={event.id} className="flex items-center gap-3 group">
              <div className={`w-1 h-10 rounded-full ${COLOR_MAP[event.color] || 'bg-blue-500'}`} />
              <div className="flex-1">
                {event.event_time && (
                  <div className="text-xs text-gray-400 dark:text-gray-500">{event.event_time}</div>
                )}
                <div className="text-sm font-medium text-gray-700 dark:text-gray-200">
                  {event.title}
                </div>
              </div>
              <button
                onClick={() => deleteEvent(event.id)}
                className="opacity-0 group-hover:opacity-100 p-1 rounded-full hover:bg-red-50 dark:hover:bg-red-950/40 transition-all"
                aria-label="Delete event"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 text-xs text-gray-400">
        {events.length} {events.length === 1 ? 'event' : 'events'} today
      </div>
    </div>
  );
}
