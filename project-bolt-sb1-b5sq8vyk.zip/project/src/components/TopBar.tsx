import { Menu, Settings, Bell, Sun, Moon, Home } from 'lucide-react';
import { useState, useEffect } from 'react';
import type { AppDef } from '@/lib/apps';

interface TopBarProps {
  onMenuClick: () => void;
  activeApp?: AppDef;
  onHome: () => void;
}

export default function TopBar({ onMenuClick, activeApp, onHome }: TopBarProps) {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('sit-theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const isDark = stored ? stored === 'dark' : prefersDark;
    setDark(isDark);
    document.documentElement.classList.toggle('dark', isDark);
  }, []);

  const toggleDark = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle('dark', next);
    localStorage.setItem('sit-theme', next ? 'dark' : 'light');
  };

  return (
    <header className="sticky top-0 z-30 bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-gray-200 dark:border-gray-800">
      <div className="flex items-center justify-between h-16 px-4 lg:px-6">
        <div className="flex items-center gap-3">
          <button
            onClick={onMenuClick}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors lg:hidden"
            aria-label="Toggle menu"
          >
            <Menu className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
          {activeApp ? (
            <button onClick={onHome} className="flex items-center gap-2 text-sm">
              <Home className="w-4 h-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200" />
              <span className="text-gray-300 dark:text-gray-600">/</span>
              <span className="font-medium text-gray-700 dark:text-gray-200">{activeApp.name}</span>
            </button>
          ) : (
            <>
              <div className="flex items-center gap-1 lg:hidden">
                <span className="text-xl font-medium text-blue-500">S</span>
                <span className="text-xl font-medium text-red-500">I</span>
                <span className="text-xl font-medium text-amber-500">T</span>
              </div>
              <div className="hidden lg:flex items-center gap-2">
                <span className="text-sm text-gray-500 dark:text-gray-400">Dashboard</span>
                <span className="text-gray-300 dark:text-gray-600">/</span>
                <span className="text-sm font-medium text-gray-700 dark:text-gray-200">Home</span>
              </div>
            </>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleDark}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            aria-label="Toggle theme"
          >
            {dark ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-gray-600" />}
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors" aria-label="Notifications">
            <Bell className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors" aria-label="Settings">
            <Settings className="w-5 h-5 text-gray-600 dark:text-gray-300" />
          </button>
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center text-white font-medium text-sm ml-1">
            U
          </div>
        </div>
      </div>
    </header>
  );
}
