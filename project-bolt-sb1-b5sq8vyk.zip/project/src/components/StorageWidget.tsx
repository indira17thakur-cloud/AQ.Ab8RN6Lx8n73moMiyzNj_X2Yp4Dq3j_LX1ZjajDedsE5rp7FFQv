import { useState, useEffect, useCallback } from 'react';
import { HardDrive, FileText, Image, Archive, Plus, Trash2, X } from 'lucide-react';
import { supabase, type DriveFile } from '@/lib/supabase';

const TOTAL_GB = 30;
const TOTAL_BYTES = TOTAL_GB * 1024 * 1024 * 1024;

const CATEGORIES = [
  { key: 'documents' as const, label: 'Documents', icon: FileText, color: 'text-blue-500' },
  { key: 'photos' as const, label: 'Photos', icon: Image, color: 'text-purple-500' },
  { key: 'archives' as const, label: 'Archives', icon: Archive, color: 'text-amber-500' },
];

function formatSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

export default function StorageWidget() {
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState<'documents' | 'photos' | 'archives'>('documents');
  const [newSize, setNewSize] = useState('');

  const fetchFiles = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('drive_files').select('*').order('created_at', { ascending: false });
    if (error) {
      console.error('Failed to load files:', error.message);
    } else {
      setFiles(data || []);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchFiles();
  }, [fetchFiles]);

  const addFile = async () => {
    const name = newName.trim();
    if (!name) return;
    const sizeBytes = Math.max(0, Math.floor(parseFloat(newSize) || 0));
    const { data, error } = await supabase
      .from('drive_files')
      .insert({ name, category: newCategory, size_bytes: sizeBytes })
      .select('*')
      .single();

    if (error) {
      console.error('Failed to add file:', error.message);
      return;
    }
    setFiles([data as DriveFile, ...files]);
    setNewName('');
    setNewCategory('documents');
    setNewSize('');
    setShowAdd(false);
  };

  const deleteFile = async (id: string) => {
    const { error } = await supabase.from('drive_files').delete().eq('id', id);
    if (error) {
      console.error('Failed to delete file:', error.message);
      return;
    }
    setFiles(files.filter((f) => f.id !== id));
  };

  const totalUsed = files.reduce((sum, f) => sum + f.size_bytes, 0);
  const usedGB = totalUsed / (1024 * 1024 * 1024);
  const percentage = Math.min(100, (totalUsed / TOTAL_BYTES) * 100);

  const categorySizes = CATEGORIES.map((cat) => ({
    ...cat,
    bytes: files.filter((f) => f.category === cat.key).reduce((sum, f) => sum + f.size_bytes, 0),
  }));

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <HardDrive className="w-4 h-4 text-emerald-500" />
          <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-200">Drive Storage</h3>
        </div>
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          aria-label="Add file"
        >
          <Plus className="w-4 h-4 text-emerald-500" />
        </button>
      </div>

      {showAdd && (
        <div className="mb-4 p-3 rounded-xl bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">New File</span>
            <button onClick={() => setShowAdd(false)} className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
              <X className="w-3.5 h-3.5 text-gray-400" />
            </button>
          </div>
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="File name"
            className="w-full px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm text-gray-700 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-400"
          />
          <div className="flex gap-2">
            <select
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value as 'documents' | 'photos' | 'archives')}
              className="flex-1 px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm text-gray-700 dark:text-gray-200 focus:outline-none"
            >
              <option value="documents">Documents</option>
              <option value="photos">Photos</option>
              <option value="archives">Archives</option>
            </select>
            <input
              type="number"
              value={newSize}
              onChange={(e) => setNewSize(e.target.value)}
              placeholder="Size (bytes)"
              min="0"
              className="w-32 px-3 py-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm text-gray-700 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-400"
            />
          </div>
          <button
            onClick={addFile}
            disabled={!newName.trim()}
            className="w-full py-2 rounded-lg bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600 disabled:opacity-40 transition-colors"
          >
            Add File
          </button>
        </div>
      )}

      <div className="mb-4">
        <div className="flex items-end justify-between mb-2">
          <span className="text-2xl font-light text-gray-700 dark:text-gray-200">
            {usedGB < 0.01 ? '0' : usedGB.toFixed(2)}<span className="text-sm text-gray-400"> GB</span>
          </span>
          <span className="text-xs text-gray-400">of {TOTAL_GB} GB</span>
        </div>
        <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-full transition-all duration-500"
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>

      <div className="space-y-2">
        {categorySizes.map((item) => (
          <div key={item.label} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <item.icon className={`w-4 h-4 ${item.color}`} />
              <span className="text-sm text-gray-600 dark:text-gray-300">{item.label}</span>
            </div>
            <span className="text-xs text-gray-400">{formatSize(item.bytes)}</span>
          </div>
        ))}
      </div>

      {files.length > 0 && (
        <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 space-y-1.5 max-h-40 overflow-y-auto">
          {files.map((file) => (
            <div key={file.id} className="flex items-center justify-between group">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-xs text-gray-500 dark:text-gray-400 truncate">{file.name}</span>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span className="text-xs text-gray-400">{formatSize(file.size_bytes)}</span>
                <button
                  onClick={() => deleteFile(file.id)}
                  className="opacity-0 group-hover:opacity-100 p-1 rounded-full hover:bg-red-50 dark:hover:bg-red-950/40 transition-all"
                  aria-label="Delete file"
                >
                  <Trash2 className="w-3 h-3 text-red-400" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <a
        href="https://drive.google.com"
        target="_blank"
        rel="noopener noreferrer"
        className="mt-4 block text-center text-xs text-emerald-500 hover:underline"
      >
        Open Drive
      </a>
    </div>
  );
}
