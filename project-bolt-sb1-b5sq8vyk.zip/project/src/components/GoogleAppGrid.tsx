import { apps, type AppId } from '@/lib/apps';

interface GoogleAppGridProps {
  onNavigate: (id: AppId) => void;
}

export default function GoogleAppGrid({ onNavigate }: GoogleAppGridProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide">Quick Access</h2>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-3">
        {apps.map((app) => (
          <button
            key={app.id}
            onClick={() => onNavigate(app.id)}
            className={`group relative flex flex-col items-center justify-center gap-3 p-5 rounded-2xl bg-gradient-to-br ${app.gradient} border border-white/60 dark:border-gray-700/40 hover:shadow-lg hover:scale-[1.03] transition-all duration-200 cursor-pointer`}
          >
            <div className="w-12 h-12 rounded-xl bg-white dark:bg-gray-800 flex items-center justify-center shadow-sm group-hover:shadow-md transition-shadow">
              <app.icon className={`w-6 h-6 ${app.iconColor}`} />
            </div>
            <div className="text-center">
              <div className="text-sm font-medium text-gray-700 dark:text-gray-200">{app.name}</div>
              <div className="text-xs text-gray-400 dark:text-gray-500">{app.description}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
