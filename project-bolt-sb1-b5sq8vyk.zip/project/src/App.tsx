import { useState, useEffect, lazy, Suspense } from 'react';
import Sidebar from '@/components/Sidebar';
import TopBar from '@/components/TopBar';
import GoogleAppGrid from '@/components/GoogleAppGrid';
import SitChat from '@/components/SitChat';
import DateTimeWidget from '@/components/DateTimeWidget';
import CalendarWidget from '@/components/CalendarWidget';
import StorageWidget from '@/components/StorageWidget';
import { Sparkles } from 'lucide-react';
import { apps, type AppId } from '@/lib/apps';

const EmailApp = lazy(() => import('@/components/apps/EmailApp'));
const CalendarApp = lazy(() => import('@/components/apps/CalendarApp'));
const DriveApp = lazy(() => import('@/components/apps/DriveApp'));
const DocsApp = lazy(() => import('@/components/apps/DocsApp'));
const SheetsApp = lazy(() => import('@/components/apps/SheetsApp'));
const SlidesApp = lazy(() => import('@/components/apps/SlidesApp'));
const PhotosApp = lazy(() => import('@/components/apps/PhotosApp'));
const ChatApp = lazy(() => import('@/components/apps/ChatApp'));
const MeetApp = lazy(() => import('@/components/apps/MeetApp'));
const PhoneApp = lazy(() => import('@/components/apps/PhoneApp'));
const KeepApp = lazy(() => import('@/components/apps/KeepApp'));
const TasksApp = lazy(() => import('@/components/apps/TasksApp'));
const ContactsApp = lazy(() => import('@/components/apps/ContactsApp'));
const TranslateApp = lazy(() => import('@/components/apps/TranslateApp'));
const BooksApp = lazy(() => import('@/components/apps/BooksApp'));

const appComponents: Record<string, React.LazyExoticComponent<React.ComponentType>> = {
  email: EmailApp,
  calendar: CalendarApp,
  drive: DriveApp,
  docs: DocsApp,
  sheets: SheetsApp,
  slides: SlidesApp,
  photos: PhotosApp,
  chat: ChatApp,
  meet: MeetApp,
  phone: PhoneApp,
  keep: KeepApp,
  tasks: TasksApp,
  contacts: ContactsApp,
  translate: TranslateApp,
  books: BooksApp,
};

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [quickAsk, setQuickAsk] = useState<string | null>(null);
  const [activeApp, setActiveApp] = useState<AppId>('home');

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as string;
      setQuickAsk(detail);
    };
    window.addEventListener('sit-quick-ask', handler);
    return () => window.removeEventListener('sit-quick-ask', handler);
  }, []);

  const navigate = (id: AppId) => {
    setActiveApp(id);
    setSidebarOpen(false);
  };

  const ActiveComponent = activeApp !== 'home' ? appComponents[activeApp] : null;
  const activeAppDef = apps.find((a) => a.id === activeApp);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} activeApp={activeApp} onNavigate={navigate} />

      <div className="lg:pl-64">
        <TopBar onMenuClick={() => setSidebarOpen(true)} activeApp={activeAppDef} onHome={() => navigate('home')} />

        <main className="px-4 lg:px-8 py-6 max-w-7xl mx-auto">
          {activeApp === 'home' ? (
            <>
              <div className="mb-6">
                <h1 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Good day</h1>
                <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">Your workspace, powered by SIT</p>
              </div>

              <SitSearchBar />

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
                <div className="lg:col-span-2 space-y-6">
                  <GoogleAppGrid onNavigate={navigate} />
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <DateTimeWidget />
                    <CalendarWidget />
                  </div>
                  <StorageWidget />
                </div>
                <div className="lg:col-span-1">
                  <div className="lg:sticky lg:top-20 h-[600px] lg:h-[calc(100vh-6rem)]">
                    <SitChat quickAsk={quickAsk} onQuickAskConsumed={() => setQuickAsk(null)} />
                  </div>
                </div>
              </div>
            </>
          ) : ActiveComponent ? (
            <div>
              {activeAppDef && (
                <div className="mb-4 flex items-center gap-2">
                  <activeAppDef.icon className={`w-5 h-5 ${activeAppDef.iconColor}`} />
                  <h1 className="text-lg font-semibold text-gray-800 dark:text-gray-100">{activeAppDef.name}</h1>
                </div>
              )}
              <Suspense fallback={<div className="flex items-center justify-center h-64 text-sm text-gray-400">Loading...</div>}>
                <ActiveComponent />
              </Suspense>
            </div>
          ) : null}
        </main>
      </div>
    </div>
  );
}

function SitSearchBar() {
  return (
    <div className="relative max-w-3xl mx-auto">
      <div className="relative group">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-400 via-red-400 to-amber-400 rounded-full opacity-20 group-hover:opacity-30 blur-sm transition-opacity" />
        <div className="relative flex items-center gap-3 bg-white dark:bg-gray-900 rounded-full border border-gray-200 dark:border-gray-700 px-5 py-3.5 shadow-sm group-hover:shadow-md transition-shadow">
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 via-red-500 to-amber-500 flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <input
            type="text"
            placeholder="Ask SIT anything..."
            className="flex-1 bg-transparent text-sm text-gray-700 dark:text-gray-200 placeholder-gray-400 focus:outline-none"
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                const input = e.currentTarget;
                if (input.value.trim()) {
                  const event = new CustomEvent('sit-quick-ask', { detail: input.value });
                  window.dispatchEvent(event);
                  input.value = '';
                }
              }
            }}
          />
          <span className="text-xs text-gray-300 dark:text-gray-600 hidden sm:block">SIT</span>
        </div>
      </div>
    </div>
  );
}

export default App;
