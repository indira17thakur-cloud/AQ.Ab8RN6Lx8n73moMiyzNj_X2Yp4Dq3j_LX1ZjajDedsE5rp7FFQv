/*
# Create calendar_events and drive_files tables (single-tenant, no auth)

1. New Tables
- `calendar_events`
  - `id` (uuid, primary key)
  - `title` (text, not null)
  - `event_date` (date, not null — the day the event occurs)
  - `event_time` (text, e.g. '9:00 AM')
  - `color` (text, color name for the accent bar, defaults to 'blue')
  - `created_at` (timestamp)

- `drive_files`
  - `id` (uuid, primary key)
  - `name` (text, not null)
  - `category` (text: 'documents', 'photos', or 'archives')
  - `size_bytes` (bigint, file size in bytes, defaults to 0)
  - `created_at` (timestamp)

2. Security
- Enable RLS on both tables.
- Allow anon + authenticated CRUD (single-tenant, no sign-in).
*/

CREATE TABLE IF NOT EXISTS calendar_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  event_date date NOT NULL DEFAULT CURRENT_DATE,
  event_time text NOT NULL DEFAULT '',
  color text NOT NULL DEFAULT 'blue',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE calendar_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_calendar_events" ON calendar_events;
CREATE POLICY "anon_select_calendar_events" ON calendar_events FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_calendar_events" ON calendar_events;
CREATE POLICY "anon_insert_calendar_events" ON calendar_events FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_calendar_events" ON calendar_events;
CREATE POLICY "anon_update_calendar_events" ON calendar_events FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_calendar_events" ON calendar_events;
CREATE POLICY "anon_delete_calendar_events" ON calendar_events FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS drive_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL CHECK (category IN ('documents', 'photos', 'archives')),
  size_bytes bigint NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE drive_files ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_drive_files" ON drive_files;
CREATE POLICY "anon_select_drive_files" ON drive_files FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_drive_files" ON drive_files;
CREATE POLICY "anon_insert_drive_files" ON drive_files FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_drive_files" ON drive_files;
CREATE POLICY "anon_update_drive_files" ON drive_files FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_drive_files" ON drive_files;
CREATE POLICY "anon_delete_drive_files" ON drive_files FOR DELETE
  TO anon, authenticated USING (true);
