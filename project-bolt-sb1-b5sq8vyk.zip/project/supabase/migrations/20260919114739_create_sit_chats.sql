/*
# Create sit_chats table (single-tenant, no auth)

1. New Tables
- `sit_chats`
  - `id` (uuid, primary key)
  - `role` (text: 'user' or 'assistant')
  - `content` (text, the message content)
  - `created_at` (timestamp, defaults to now)

2. Security
- Enable RLS on `sit_chats`.
- Allow anon + authenticated CRUD because the app is intentionally shared/public (no sign-in screen).
*/

CREATE TABLE IF NOT EXISTS sit_chats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sit_chats ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_sit_chats" ON sit_chats;
CREATE POLICY "anon_select_sit_chats" ON sit_chats FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_sit_chats" ON sit_chats;
CREATE POLICY "anon_insert_sit_chats" ON sit_chats FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_sit_chats" ON sit_chats;
CREATE POLICY "anon_update_sit_chats" ON sit_chats FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_sit_chats" ON sit_chats;
CREATE POLICY "anon_delete_sit_chats" ON sit_chats FOR DELETE
  TO anon, authenticated USING (true);
