/*
# Create tables for SIT dashboard apps (single-tenant, no auth)

1. New Tables
- `emails` — SIT Email app: inbox/sent/draft emails
  - id, sender, recipient, subject, body, folder (inbox/sent/drafts/trash),
    is_starred, is_read, created_at
- `notes` — Keep app: sticky notes
  - id, title, content, color, created_at
- `tasks` — Tasks app: to-do items
  - id, title, completed, created_at
- `contacts` — Contacts app: contact list
  - id, name, email, phone, company, created_at
- `documents` — Docs app: text documents
  - id, title, content, created_at, updated_at
- `spreadsheets` — Sheets app: spreadsheet data
  - id, title, data (jsonb), created_at, updated_at
- `presentations` — Slides app: slide decks
  - id, title, slides (jsonb), created_at, updated_at
- `photos` — Photos app: photo metadata (name + url)
  - id, title, image_url, created_at
- `forms` — Forms app: form definitions
  - id, title, description, questions (jsonb), created_at

2. Security
- Enable RLS on all tables.
- Allow anon + authenticated CRUD (single-tenant, no sign-in).
*/

CREATE TABLE IF NOT EXISTS emails (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender text NOT NULL DEFAULT '',
  recipient text NOT NULL DEFAULT '',
  subject text NOT NULL DEFAULT '',
  body text NOT NULL DEFAULT '',
  folder text NOT NULL DEFAULT 'inbox' CHECK (folder IN ('inbox', 'sent', 'drafts', 'trash')),
  is_starred boolean NOT NULL DEFAULT false,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE emails ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_crud_emails" ON emails;
CREATE POLICY "anon_crud_emails" ON emails FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '',
  content text NOT NULL DEFAULT '',
  color text NOT NULL DEFAULT 'amber',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE notes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_crud_notes" ON notes;
CREATE POLICY "anon_crud_notes" ON notes FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  completed boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_crud_tasks" ON tasks;
CREATE POLICY "anon_crud_tasks" ON tasks FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  company text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_crud_contacts" ON contacts;
CREATE POLICY "anon_crud_contacts" ON contacts FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'Untitled',
  content text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_crud_documents" ON documents;
CREATE POLICY "anon_crud_documents" ON documents FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS spreadsheets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'Untitled',
  data jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE spreadsheets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_crud_spreadsheets" ON spreadsheets;
CREATE POLICY "anon_crud_spreadsheets" ON spreadsheets FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS presentations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'Untitled',
  slides jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE presentations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_crud_presentations" ON presentations;
CREATE POLICY "anon_crud_presentations" ON presentations FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'Untitled',
  image_url text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_crud_photos" ON photos;
CREATE POLICY "anon_crud_photos" ON photos FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS forms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'Untitled Form',
  description text NOT NULL DEFAULT '',
  questions jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE forms ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_crud_forms" ON forms;
CREATE POLICY "anon_crud_forms" ON forms FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
