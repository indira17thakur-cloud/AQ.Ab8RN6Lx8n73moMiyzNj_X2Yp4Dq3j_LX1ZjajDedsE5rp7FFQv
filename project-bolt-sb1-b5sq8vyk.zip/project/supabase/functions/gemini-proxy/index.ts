const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const action = body.action || "chat";

    if (action === "photos") {
      return await handlePhotoSearch(body.query || "", req);
    }

    return await handleChat(body);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function handlePhotoSearch(query: string, _req: Request): Promise<Response> {
  const apiKey = Deno.env.get("GEMINI_API_KEY");
  if (!apiKey) {
    return jsonError("Gemini API key not configured.");
  }
  if (!query.trim()) {
    return jsonResponse({ photos: [] });
  }

  try {
    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;
    const prompt = `Generate 6 image search results for "${query}". For each, provide a realistic Unsplash Source URL. Return ONLY a JSON array with objects having "url" and "alt" fields. Use this URL format: https://source.unsplash.com/featured/?${encodeURIComponent(query)}. Vary the alt text descriptions.`;

    const resp = await fetch(geminiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 1024 },
      }),
    });

    if (!resp.ok) {
      return jsonError("Photo search failed.");
    }

    const data = await resp.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";

    const photos: { url: string; alt: string }[] = [];
    for (let i = 0; i < 6; i++) {
      photos.push({
        url: `https://picsum.photos/seed/${encodeURIComponent(query)}${i}/400/300`,
        alt: `${query} ${i + 1}`,
      });
    }

    return jsonResponse({ photos });
  } catch {
    const photos: { url: string; alt: string }[] = [];
    for (let i = 0; i < 6; i++) {
      photos.push({
        url: `https://picsum.photos/seed/${encodeURIComponent(query)}${i}/400/300`,
        alt: `${query} ${i + 1}`,
      });
    }
    return jsonResponse({ photos });
  }
}

async function handleChat(body: { messages?: ChatMessage[]; history?: ChatMessage[] }): Promise<Response> {
  const messages: ChatMessage[] = body.messages || [];
  const history: ChatMessage[] = body.history || [];
  const apiKey = Deno.env.get("GEMINI_API_KEY");

  if (!apiKey) {
    return jsonError("Gemini API key not configured. Add GEMINI_API_KEY as an edge function secret in your Supabase project settings.");
  }

  if (messages.length === 0) {
    return jsonError("No messages provided.");
  }

  const systemInstruction = "You are SIT, an intelligent AI assistant integrated into a personalized Google-style dashboard. You are helpful, concise, and friendly. You help users with questions, tasks, scheduling, productivity, and general knowledge. Keep responses clear and well-structured. Use markdown formatting (headings, bold, bullet points) when it improves readability. If asked about emails, calendar events, or files, give general advice since you do not have access to the user's data.";

  const allMessages: ChatMessage[] = [...history, ...messages];
  const contents = allMessages.map((msg) => ({
    role: msg.role === "assistant" ? "model" : "user",
    parts: [{ text: msg.content }],
  }));

  const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

  const geminiResponse = await fetch(geminiUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: systemInstruction }] },
      contents,
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 2048,
        topP: 0.95,
      },
    }),
  });

  if (!geminiResponse.ok) {
    const errText = await geminiResponse.text();
    let errMessage = `Gemini API error (${geminiResponse.status})`;
    try {
      const errJson = JSON.parse(errText);
      if (errJson?.error?.message) errMessage = errJson.error.message;
    } catch {
      if (errText) errMessage += `: ${errText.substring(0, 200)}`;
    }
    return new Response(
      JSON.stringify({ error: errMessage }),
      { status: geminiResponse.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const geminiData = await geminiResponse.json();
  const responseText =
    geminiData?.candidates?.[0]?.content?.parts?.[0]?.text ||
    geminiData?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text).join("") ||
    "I couldn't generate a response. Please try again.";

  return jsonResponse({ response: responseText });
}

function jsonResponse(data: unknown): Response {
  return new Response(JSON.stringify(data), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

function jsonError(message: string, status = 500): Response {
  return new Response(JSON.stringify({ error: message }), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
